#' X0, BC data
#'
#' @format data.frame
"X0"
