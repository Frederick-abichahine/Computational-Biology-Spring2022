#' k_results, results of eval_k function
#'
#' @format list
"k_results"
