#' ind_adj,  index of neighbour for each genes using STRING interactome
#'
#' @format list
"ind_adj"
