#' Adjacency matrix
#'
#' @format matrix
"A"
