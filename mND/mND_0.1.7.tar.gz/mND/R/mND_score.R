#' mND_score, output of mND
#'
#' @format list
"mND_score"
