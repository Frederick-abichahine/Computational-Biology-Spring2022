#' Xs, BC data diffused
#'
#' @format matrix
"Xs"
