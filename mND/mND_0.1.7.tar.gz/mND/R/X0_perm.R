#' X0_perm, BC data permutated
#'
#' @format list of matrix
"X0_perm"
