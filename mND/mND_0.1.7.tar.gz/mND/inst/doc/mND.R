## ---- eval=FALSE---------------------------------------------------------
#  install.packages("igraph")
#  install.packages("/path_to_package/mND_xxx.tar.gz", repos = NULL)
#  library(mND)

## ---- eval=F, message=FALSE, warning = FALSE-----------------------------
#  W <- normalize_adj_mat(A)
#  X0_perm <- perm_X0(X0, r = 50, W)
#  Xs <- ND(X0_perm, W, cores = 4)
#  ind_adj <- neighbour_index(W)
#  mND_score <- mND(Xs, ind_adj, k = 3, cores = 4)
#  mND_score <- signif_assess(mND_score)
#  class_res <- classification(mND_score, X0, Hl, top, alpha)
#  plot_results(mND_score, class_res, W, n = 150, directory = "~/mND_results")

## ---- eval=F, message=FALSE, warning = FALSE-----------------------------
#  W <- normalize_adj_mat(A)
#  mND_score <- framework_mND(X0, W, k = 3, r = 50, cores = 4)
#  class_res <- classification(mND_score, X0, Hl, top, alpha)
#  plot_results(mND_score, class_res, W, n = 150, directory = "~/mND_results")

## ---- eval=TRUE, message=FALSE, collapse=TRUE----------------------------
library(mND)
data(X0)
head(X0,3) #L1: mutations, L2: gene expression variations

data(A) #adjacency matrix of STRING itnteractome

## ---- eval=FALSE, message=FALSE------------------------------------------
#  library(mND)
#  W <- normalize_adj_mat(A)
#  X0_perm <- perm_X0(X0, r = 50, W, seed_n = 2)

## ---- eval=F, message=FALSE, echo=FALSE, results='hide'------------------
#  library(mND)
#  W <- normalize_adj_mat(A)

## ---- eval=FALSE, message=FALSE------------------------------------------
#  library(mND)
#  Xs <- ND(X0_perm, W, cores = 4)

## ---- fig.width=7,eval=T, fig.height=4, echo=FALSE, results='hide',message=FALSE----
data(Xs)
par(mfrow=c(1, 2))
par(mar = c(4,5,3,1))
X0 <- as.data.frame(X0)
X0$r <- rank(-X0$L2)
#col_X0 <- ifelse(X0[,1]>0 & 10^(-X0[,2])<=0.05, "green", ifelse(X0[,1]>0, "yellow", ifelse(10^(-X0[,2])<=0.05, "blue","red")))
col_X0 <- ifelse(X0[,1]>0 & X0$r <=1200, "green", ifelse(X0[,1]>0, "yellow", ifelse(X0$r <=1200, "blue","red")))
plot(X0[,1]/max(X0[,1]), X0[,2]/max(X0[,2]),col="black", bg=adjustcolor(col_X0,0.7), pch=21,ylab=expression(x[2]),xlab=expression(x[1]))
legend("topright",c("Top ranking genes in x1 and x2", "Top ranking genes in x1", "Top ranking genes in x2", "not significant in x1 and x2"), col="black", pt.bg=c("green", "yellow", "blue", "red"), pch=21, cex=0.6)
plot(Xs[[1]][,1]/max(Xs[[1]][,1]), Xs[[1]][,2]/max(Xs[[1]][,2]),col="black", bg=adjustcolor(col_X0,0.7), pch=21, ylab=expression(x[2]^{'*'}),xlab=expression(x[1]^{'*'}))
legend("topright",c("Top ranking genes in x1 and x2", "Top ranking genes in x1", "Top ranking genes in x2", "not significant in x1 and x2"), col="black", pt.bg=c("green", "yellow", "blue", "red"), pch=21, cex=0.6)

## ---- eval=FALSE, message=FALSE------------------------------------------
#  library(mND)
#  ind_adj <- neighbour_index(W)

## ---- eval=F, message=FALSE----------------------------------------------
#  library(mND)
#  mND_score <- mND(Xs, ind_adj, k=3, cores = 4)

## ---- eval=T, echo=FALSE,message=FALSE-----------------------------------
data("mND_score")

## ---- eval=T, message=FALSE----------------------------------------------
library(mND)
mND_score <- signif_assess(mND_score)

## ---- eval=T, message=FALSE, collapse=TRUE-------------------------------
library(mND)
data(X0)
Hl <- list(l1 = rownames(X0[X0[,1]>0,]), 
           l2 = names(X0[order(X0[,2], decreasing = T),2][1:1200])
)
top_Nl <- unlist(lapply(Hl, function(x) length(x)))
top_Nl

class_res <- classification(mND_score, X0, Hl, top = top_Nl)

#Classification of genes in every layer
head(class_res$gene_class)

#Occurrence of (M; L; I; NS) for each gene across layers
head(class_res$occ_labels)

## ---- eval=F, message=FALSE----------------------------------------------
#  library(mND)
#  plot_results(mND_score, class_res, W, n = 150, directory = "~/mND_results")

## ---- fig.width=6,eval=T, fig.height=7, echo=FALSE, results='hide',message=FALSE----
layout(matrix(c(1,3,2,3), nrow=2, byrow = T), widths = c(0.7,0.3))
par(mar = c(5.5,7,2,3))
plot(mND_score$mND$mND, -log10(mND_score$mND$p), col="black", cex=0.7, pch=16, ylab="-log10(p)", xlab="mND")
abline(h=-log10(0.05), lty=2, lwd=2, col="orange")
W <- normalize_adj_mat(A)
g <- graph_from_adjacency_matrix(W, weighted = T, mode = "undirected")
mND_score2 <- mND_score$mND
mND_score2 <- mND_score2[order(mND_score2$mNDp,decreasing = T),]
mND_score2 <- mND_score2[1:150,]

g_sub <- induced_subgraph(g, V(g)$name %in% rownames(mND_score2))
par(mar=c(0.5,1,0,0))
 plot.igraph(g_sub,
                  vertex.label=NA,
                  vertex.size=6.5,
                  edge.width=0.8,
                  edge.color='hotpink',
                  edge.lty=2,
                  edge.width = 0.7,
                  layout=layout_with_kk)
 
class_genes <- class_res$gene_class
#  Set these as the levels for each column
n=100
rotate <- function(x) t(apply(x, 2, rev))
nL <- dim(class_genes)[2]
temp2 <-ifelse(class_genes=="M", 3, ifelse(class_genes=="L", 2,ifelse(class_genes=="I", 1,0 )))
temp2 <- temp2[1:n,]
tt <- rotate(temp2)
par(mar = c(2.5,6,0.5,2))
  image(tt, col =c('0' = "gray75", '1' = "chocolate4", '2' = "chocolate1", '3' = "purple"),xaxt="none", yaxt="none")
  xx <- seq(0, 1, length.out = ncol(temp2))
  yy <- seq(1, 0, length.out = nrow(temp2))
  aa<-seq(0,n)
  bb <- seq(0,nL)
  cc <- aa*yy[n-1]+yy[n-1]/2
  vv <- xx+xx[2]/2
  abline(v=vv, col="black", xpd=F)
  abline(h=cc, col="black", xpd=F)
  axis(1, xx,colnames(temp2),  cex.axis=0.7)
  axis(2, yy,rownames(temp2),  cex.axis=0.7, las=2)

## ---- eval=F, message=FALSE----------------------------------------------
#  library(mND)
#  
#  k_val <- seq(1,5,1)
#  k_results <- optimize_k(Xs, X0, k_val, ind_adj, W, top = 200, cores = 4)

## ---- fig.width=4, eval=T, fig.height=4, echo=FALSE, results='hide',message=FALSE----
j<-1
data(k_results)
k_val <- seq(1,5,1)
par(mar = c(5,4,2,3))
  plot(k_results[[j]], type="l", ylim=c(0, max(unlist(k_results))), ylab=expression(omega), xlab="n")
  for(j in 2:length(k_results)){ #k
    lines(k_results[[j]], col=j)
  }
legend("bottomright", legend = k_val, col=1:length(k_val), lty= 1, cex=0.7)

