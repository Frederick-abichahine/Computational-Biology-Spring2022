#' An example of filtering setting file
#'
#' @format tab-delimited text file
"filter_setting"
