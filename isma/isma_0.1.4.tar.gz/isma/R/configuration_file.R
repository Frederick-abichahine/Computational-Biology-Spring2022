#' An example of configuration file for the pre_process() function
#'
#' @format tab-delimited files
"configuration_file"

