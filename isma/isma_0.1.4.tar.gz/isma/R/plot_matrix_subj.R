#' Plot similarity matrix
#'
#' @param ov_sub_cl similarity matrix obtained overlap_Subjects
#' @param ov_cv cv matrix obtained from overlap_Subjects

plot_matrix_subj <- function(ov_sub_cl, ov_cv){

  rotate <- function(x) t(apply(x, 2, rev))
  ov_samples_sites<-ov_sub_cl
  ov_samples_sites <- log(ov_sub_cl+1)
  ov_samples_sites[is.infinite(ov_samples_sites)] <- -1
  ov_samples_sites[upper.tri(ov_samples_sites)] <- NA
  M2 <- ov_cv
  M2[is.na(M2)] <- -1
  M2[lower.tri(M2)] <- NA

  par(mar = c(5,5,1,1))
  image(rotate(M2), col= c("grey75",brewer.pal(n = 9, "Greens")), breaks=(c(-1,seq(-0.90, max(na.omit(c(M2))), length.out = 10))), xaxt="none", yaxt="none")
  grid(ncol(ov_samples_sites), nrow(ov_samples_sites), lty=1, lwd=0.5)
  axis(1, seq(0, nrow(ov_samples_sites)-1, length.out = nrow(ov_samples_sites))/(ncol(ov_samples_sites)-1), colnames( ov_samples_sites), las=2, cex.axis=0.5)
  axis(2, seq(0, nrow(ov_samples_sites)-1, length.out = nrow(ov_samples_sites))/(ncol(ov_samples_sites)-1), rev(rownames( ov_samples_sites)), las=2, cex.axis=0.5)
  image(rotate(ov_samples_sites), col=c("grey75",rev(heat.colors(9))),breaks=(c(-1,seq(0, max(na.omit(c(ov_samples_sites))), length.out = 10))), xaxt="none", yaxt="none", add=T)
  grid(ncol(ov_samples_sites), nrow(ov_samples_sites), lty=1, lwd=0.5)

  xx <- seq(0, 1, length.out = ncol(ov_samples_sites))
  yy <- seq(0, 1, length.out = nrow(ov_samples_sites))

  ov_sub_bin <- matrix(0,ncol=dim(ov_cv)[1], nrow = dim(ov_cv)[2])
  diag(ov_sub_bin) <- ifelse(diag(ov_cv)>=1,1,0)
  for(i in 1:dim(ov_sub_bin)[1]){
    for(j in 1:dim(ov_sub_bin)[1]){
      if( ov_sub_bin[i,j] == 1){
        text(xx[i], rev(yy)[j], "*", font=2, cex=0.7) #mutated
      }
    }
  }
}
