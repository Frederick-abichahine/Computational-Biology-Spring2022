#' List of some output of gene_analysis
#'
#' @format data.frame
"output_GA"
