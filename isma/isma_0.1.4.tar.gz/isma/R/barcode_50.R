#' Vector of 50 barcodes
#'
#' @format vector
"barcode_50"
