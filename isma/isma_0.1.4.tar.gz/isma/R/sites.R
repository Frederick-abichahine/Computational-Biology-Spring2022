#' Integration of mutation sites collect from get_TCGA_sites and detect by 4 mutation callers
#'
#' @format data.frame
"sites"
