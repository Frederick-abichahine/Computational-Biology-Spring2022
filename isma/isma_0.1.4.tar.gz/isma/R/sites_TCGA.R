#' Integration of informations from integrate_TCGA
#'
#' @format data.frame
"sites_TCGA"
