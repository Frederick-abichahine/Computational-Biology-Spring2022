#' Calculates the variation of site amount, considering separately each subject and returns the results for each caller.
#'
#' @param all.sites.methods data.frame produced by pre_process or get_TCGA_sites or site_annotation functions
#' @param site All/coding/noncoding
#' @param type type of analysis: Site or Gene
#' @param bin number of points into which the explored interval is discretized
#' @param fileSetting configuration file name
#' @return list:
#' \itemize{
#' \item{for each parameter a list of matrices, one for each subject, with site amount at varying parameter values in each tool;}
#' \item{matrix with settings.}
#' }
#' @importFrom utils read.table
#' @export


ese_subj_tool <- function(all.sites.methods, site = "All", type = NULL, bin = NULL, fileSetting = NULL){
  if(is.null(type)){
    stop("You have to define type. The options are: \"Site\" or \"Gene\".")
  }
  if(type=="Gene" & !"Gene" %in% colnames(all.sites.methods)){
    stop("The sites are not annotated! You should use: \"type = Site\"")
  }
  if(nrow(all.sites.methods)==0){
    stop("The dataframe with the sites is empty.")
  } else if (nrow(all.sites.methods)>0 & type=="Site"){
    all.sites.methods <- all.sites.methods[!duplicated(all.sites.methods[,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject', 'Tool_ID')]), ]
  }
  #For analyzing only coding mutation sites
  if(site %in% c("coding", "noncoding") & !"Location" %in% colnames(all.sites.methods)){
    stop("The sites are not annotated, you should use site = All")
  }
  if(site!="All"){
    switch(site,
           coding ={    all.sites.methods <- all.sites.methods[which(all.sites.methods$Location %in% "coding"), ]
           nrowSitesNew <- nrow(all.sites.methods)
           if(nrowSitesNew==0) {stop("No coding sites")}
           },
           noncoding ={   all.sites.methods <- all.sites.methods[which(all.sites.methods$Location %in% "noncoding"), ]
           nrowSitesNew <- nrow(all.sites.methods)
           if(nrowSitesNew==0) {stop("No noncoding sites")}
           },
           {
             stop(sprintf(paste("Wrong type of site selected: ", site, ". You can use: coding, noncoding or All for both.")))
           }
    )
  }
  if(is.null(fileSetting)){
    parameter = c("Tumor_var_reads", "Normal_var_reads", "Tumor_Vaf", "Normal_Vaf", "Tumor_reads", "Normal_reads");
    operator = c(">=", "<=", ">=", "<=", ">=",">=")
    Subject_ID <- unique(all.sites.methods$Subject_ID)
    settingParameter <- data.frame()
    for(j in 1:length(parameter)){
      for(i in 1:length(Subject_ID)){
        minValue <- min(all.sites.methods[all.sites.methods$Subject_ID==Subject_ID[i],parameter[j]])
        maxValue <- max (all.sites.methods[all.sites.methods$Subject_ID==Subject_ID[i],parameter[j]])
        temp <- data.frame(parameter=parameter[j], Subject_ID = Subject_ID[i], minValue, maxValue, operator=operator[j], stringsAsFactors = FALSE)
        settingParameter <- rbind(settingParameter, temp)
      }
    }
  } else {settingParameter <- read.table(fileSetting, header=TRUE, stringsAsFactors = FALSE, sep="\t")}
  if(is.null(fileSetting) & is.null(bin)){
    settingParameter$bin <- rep(20, nrow(settingParameter))
  } else if((is.null(fileSetting) & !is.null(bin))){
    settingParameter$bin <- rep(bin, nrow(settingParameter))
  }
  logicColumnPresence <- unlist(apply(all.sites.methods[as.character(settingParameter$parameter)], 2, function(x) any(!is.na(x))))
  settingParameter <- settingParameter[logicColumnPresence, ]
  if(nrow(settingParameter)==0){
    stop("The columns in the dataframe of the selected parameters have \"NA\" values")
  }
  #Unique tool-ID and subject-ID
  Subject_ID <- as.character(unique(all.sites.methods$Subject_ID))
  parameter <- as.character(unique(settingParameter$parameter))
  #List for save the data.frame for each parameter
  filteringOutputBySubjectTool <- vector('list', length(parameter))
  for (j in 1:length(parameter)) {
    Subject_ID <- unique(settingParameter[settingParameter==parameter[j], "Subject_ID"])
    filteringOutputTemp <- vector('list', length(Subject_ID))
    for (i in 1:length(Subject_ID)) {
      #Extract all mutation sites of the Tool_ID[i]
      tempSubject <- all.sites.methods[all.sites.methods$Subject_ID == Subject_ID[i], ]
      operator <-  settingParameter[settingParameter$parameter==parameter[j] & settingParameter$Subject_ID==Subject_ID[i], "operator"]
      Tool_ID <- as.character(unique(tempSubject$Tool_ID))
      #The min and the max for the Tool_ID[i] and the parameter[j]
      #will be used for the generate the sequence vector useful for
      #analyzing the variation of the amount of mutations sites for
      #each Subject_ID in each tool
      min_Subject <- settingParameter[settingParameter$parameter==parameter[j] & settingParameter$Subject_ID==Subject_ID[i], "minValue"]
      max_Subject <- settingParameter[settingParameter$parameter==parameter[j] & settingParameter$Subject_ID==Subject_ID[i], "maxValue"]
      bin <- settingParameter[settingParameter$parameter==parameter[j] & settingParameter$Subject_ID==Subject_ID[i], "bin"]
      #Initializa empty data.frame:
      #outBySubject for analyzing the variation of the amount of mutations sites for
      #each Subject_ID in each tool
      outBySubject <- matrix(data = NA, nrow = bin, ncol = length(Tool_ID))
      colnames(outBySubject) <- as.character(Tool_ID)
      outBySubject <- data.frame(par=0, outBySubject, stringsAsFactors = F)
      outBySubject$par <- seq(as.numeric(min_Subject), as.numeric(max_Subject), length.out = as.numeric(bin))
      for (k in 1:length(Tool_ID)) {
        tempTool <- tempSubject[tempSubject$Tool_ID == Tool_ID[k], ]
        if (nrow(tempTool)>0){
          switch(type,
                 "Site"={
                   switch(operator,
                          "<="={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                 function(x) nrow(tempTool[abs(tempTool[parameter[j]]) <= x, ]))
                          },
                          ">="={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                 function(x) nrow(tempTool[abs(tempTool[parameter[j]]) >= x, ]))
                          },
                          "=="={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                 function(x) nrow(tempTool[abs(tempTool[parameter[j]]) == x, ]))
                          },
                          "!="={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                 function(x) nrow(tempTool[abs(tempTool[parameter[j]]) != x, ]))
                          },
                          ">"={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                function(x) nrow(tempTool[abs(tempTool[parameter[j]]) > x, ]))
                          },
                          "<"={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                function(x) nrow(tempTool[abs(tempTool[parameter[j]]) < x, ]))
                          },
                          { stop(sprintf(paste("Wrong Operator: ", operator, ", please use: <=, <, ==, >, >=, !=" )))
                          }
                   )
                 },
                 "Gene"={
                   switch(operator,
                          "<="={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                 function(x) length(unique(tempTool[abs(tempTool[parameter[j]]) <= x, "Gene" ])))
                          },
                          ">="={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                 function(x) length(unique(tempTool[abs(tempTool[parameter[j]]) >= x, "Gene" ])))
                          },
                          "=="={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                 function(x) length(unique(tempTool[abs(tempTool[parameter[j]]) == x, "Gene" ])))
                          },
                          "!="={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                 function(x) length(unique(tempTool[abs(tempTool[parameter[j]]) != x, "Gene" ])))
                          },
                          ">"={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                function(x) length(unique(tempTool[abs(tempTool[parameter[j]]) > x, "Gene" ])))
                          },
                          "<"={ outBySubject[, k + 1] <- sapply(outBySubject$par,
                                                                function(x) length(unique(tempTool[abs(tempTool[parameter[j]]) < x, "Gene" ])))
                          },
                          { stop(sprintf(paste("Wrong Operator: ", operator, ", please use: <=, <, ==, >, >=, !=" )))
                          }
                   )
                 }, {stop(sprintf(paste("Wrong type: ", type, ", please use: Site or Gene.")))}
          )
        }else {
          outBySubject[, k + 1] <- rep(0, bin)
        }
        filteringOutputTemp[[i]] <- outBySubject
      }
      names(filteringOutputTemp) <- Subject_ID
      filteringOutputBySubjectTool[[j]] <- filteringOutputTemp
    }
  }
  #Rename by the parameter
  names(filteringOutputBySubjectTool) <- parameter
  listOutput <- list(filtering_output = filteringOutputBySubjectTool, setting_filtering = settingParameter)
  return(listOutput)
}
