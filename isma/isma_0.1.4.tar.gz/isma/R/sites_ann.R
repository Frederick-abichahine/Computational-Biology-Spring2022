#' List of annotated sites
#'
#' @format data.frame
"sites_ann"
