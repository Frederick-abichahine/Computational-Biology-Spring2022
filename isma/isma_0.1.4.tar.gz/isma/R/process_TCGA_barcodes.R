#' Internal function
#'
#' @param x TCGA barcode

process_TCGA_barcodes <- function(x){

  out <- lapply(x, function(x) unlist(strsplit(x, "-")))
  out <- do.call(rbind, out)
  colnames(out) <- c("Project", "TSS", "Participant", "SampleVial", "PortionAnalyte", "Plate", "Center")
  out <- data.frame(Barcode=x, out, stringsAsFactors = F)
  return(out)
}
