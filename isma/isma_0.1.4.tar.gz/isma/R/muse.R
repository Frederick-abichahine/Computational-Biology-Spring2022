#' Read vcf of MuSe and standardized file into a unique matrix.
#'
#' @param fileToolList List of files separated by tools
#' @param fileList  list with all files and informations
#' @param i Index of fileToolList
#' @param k Index of the iteration
#' @param all_sites Empty list in which will be save the mutation sites


muse <- function(fileToolList, fileList,i,k, all_sites){

  for (j in 1:length(fileToolList[[i]])){

    file <- read_VCF(fileToolList, fileList,i,j)
    file_pass <- file[file$FILTER=="PASS",]
    indAD <- which(unlist(strsplit(file_pass[1,"FORMAT"],":"))=="AD")
    file_temp1 <- file_pass[grep(",",file_pass$ALT),]
    site_temp <- data.frame()
    if (dim(file_temp1)[1]>0){
      file_pass <- file_pass[-grep(",", file_pass$ALT), ]

      for (t in 1:dim(file_temp1)[1]){
        tempALT <- unlist(strsplit(file_temp1$ALT[t],","))
        tempCountT <- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$TUMOR[t],":"))[indAD], ",")))
        tempCountC <- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$NORMAL[t],":"))[indAD], ",")))

        for(f in 1:length(tempALT)){
          site_temp <- rbind(site_temp,data.frame(
            file_temp1[t, c("CHROM","POS","REF")],
            ALT = tempALT[f],
            Design = fileList$Design[fileToolList[[i]][j]==fileList$File],
            #  INFO = "2",
            Tumor_ref_reads = tempCountT[1],
            Tumor_var_reads = tempCountT[f+1],
            Normal_ref_reads = tempCountC[1],
            Normal_var_reads = tempCountC[f+1],
            Subject_ID = fileList$Subject_ID[fileToolList[[i]][j]==fileList$File],
            Variant_Type = ifelse((sapply(file_temp1$REF[t], function(x) length(unlist(strsplit(x, "")))) + sapply(tempALT[f], function(x) length(unlist(strsplit(x, ""))))==2),"SNP","INDEL"),
            Tool_ID = names(fileToolList)[i],stringsAsFactors = FALSE)
          )
          site_temp[is.na(site_temp)] <-0
        }
      }
    }

    temp1C <- apply(file_pass,1,function(x) as.numeric(unlist(strsplit(unlist(strsplit(x["TUMOR"],":"))[indAD], ","))))
    temp2C <- apply(file_pass,1,function(x) as.numeric(unlist(strsplit(unlist(strsplit(x["NORMAL"],":"))[indAD], ","))))

    file_pass <- data.frame(
      file_pass[,c("CHROM","POS","REF","ALT")],
      Design = fileList$Design[fileToolList[[i]][j]==fileList$File],
      #   INFO = "2",
      Tumor_ref_reads = temp1C[1,],
      Tumor_var_reads = temp1C[2,],
      Normal_ref_reads = temp2C[1,],
      Normal_var_reads = temp2C[2,],
      Subject_ID = fileList$Subject_ID[fileToolList[[i]][j]==fileList$File],
      Variant_Type = ifelse((sapply(file_pass$REF, function(x) length(unlist(strsplit(x, "")))) + sapply(file_pass$ALT, function(x) length(unlist(strsplit(x, ""))))==2),"SNP","INDEL"),
      Tool_ID = names(fileToolList)[i],
      stringsAsFactors = FALSE)

    file_pass <- rbind(file_pass, site_temp)
    all_sites[[k]] <- file_pass
    k = k+1
  }
  newL <- list(all_sites = all_sites, ind = k)
  return(newL)
}
