#' Read vcf of Strella and standardized file into a unique matrix.
#'
#' @param fileToolList List of files separated by tools
#' @param fileList  list with all files and informations
#' @param i Index of fileToolList
#' @param k Index of the iteration
#' @param all_sites Empty list in which will be save the mutation sites
#' @param nucl nucleotide


strelka <- function(fileToolList, fileList, i, k, all_sites, nucl){
  for (j in 1:length(fileToolList[[i]])){
    file <- read_VCF(fileToolList, fileList, i, j)
    if(dim(file)[1]!=0){
      file_pass <- file[file$FILTER=="PASS", ]
      file_pass <- file_pass[which(file_pass$REF %in% nucl),]
      vectNucleotide <- c("AU","CU","GU","TU")
      indNucl <- which(unlist(strsplit(file_pass[1,"FORMAT"], ":"))== vectNucleotide)
      file_temp1<- file_pass[grep(",", file_pass$ALT), ]
      site_temp <- data.frame()
      if (dim(file_temp1)[1]>0){
        file_pass<- file_pass[-grep(",",file_pass$ALT), ]
        for (t in 1:dim(file_temp1)[1]){
          tempALT<- unlist(strsplit(file_temp1$ALT[t], ","))
          indRef <- grep(file_temp1$REF[t], nucl)
          tempTref<- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$TUMOR[t],":"))[indNucl-1+indRef], ",")))[1]
          tempCref<- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$NORMAL[t],":"))[indNucl-1+indRef], ",")))[1]
          for(f in 1:length(tempALT)){

            indAlt <- grep(tempALT[f], nucl)
            tempTalt<- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$TUMOR[t],":"))[indNucl-1+indAlt], ",")))[1]
            tempCalt<- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$NORMAL[t],":"))[indNucl-1+indAlt], ",")))[1]

            site_temp<-rbind(site_temp,data.frame(
              file_temp1[t, c("CHROM","POS","REF")],
              ALT = tempALT[f],
              Design = fileList$Design[fileToolList[[i]][j]==fileList$File],
              # INFO = as.numeric("2"),
              Tumor_ref_reads = tempTref,
              Tumor_var_reads = tempTalt,
              Normal_ref_reads = tempCref,
              Normal_var_reads = tempCalt,
              Subject_ID = fileList$Subject_ID[fileToolList[[i]][j]==fileList$File],
              Variant_Type = ifelse((sapply(file_temp1$REF[t], function(x) length(unlist(strsplit(x, "")))) + sapply(tempALT[f], function(x) length(unlist(strsplit(x, ""))))==2), "SNP", "INDEL"),
              Tool_ID = names(fileToolList)[i],
              stringsAsFactors = FALSE))
            site_temp[is.na(site_temp)] <- 0
          }
        }
      }

      indRef <- apply(file_pass, 1, function(x) grep(x["REF"], nucl))
      indAlt <- apply(file_pass, 1, function(x) grep(x["ALT"], nucl))
      tempT <- apply(file_pass, 1, function(x) as.numeric(sapply(unlist(strsplit(x["TUMOR"],":"))[indNucl], function(x) unlist(strsplit(x,",")))[1,]))
      tempC <- apply(file_pass, 1 ,function(x) as.numeric(sapply(unlist(strsplit(x["NORMAL"],":"))[indNucl], function(x) unlist(strsplit(x,",")))[1,]))
      tempTref <- rep(0, dim(file_pass)[1])
      tempCref <- rep(0, dim(file_pass)[1])
      tempTalt <- rep(0, dim(file_pass)[1])
      tempCalt <- rep(0, dim(file_pass)[1])
      for(t in 1:dim(file_pass)[1]){
        tempTref[t] <- tempT[indRef[t], t]
        tempCref[t] <- tempC[indRef[t], t]
        tempTalt[t] <- tempT[indAlt[t], t]
        tempCalt[t] <- tempC[indAlt[t], t]
      }
      file_pass <- data.frame(
        file_pass[,c("CHROM","POS","REF","ALT")],
        Design = fileList$Design[fileToolList[[i]][j]==fileList$File],
        # INFO = as.numeric("2"),
        Tumor_ref_reads = tempTref,
        Tumor_var_reads = tempTalt,
        Normal_ref_reads = tempCref,
        Normal_var_reads = tempCalt,
        Subject_ID = fileList$Subject_ID[fileToolList[[i]][j]==fileList$File],
        Variant_Type = ifelse((sapply(file_pass$REF, function(x) length(unlist(strsplit(x, "")))) + sapply(file_pass$ALT, function(x) length(unlist(strsplit(x, ""))))==2),"SNP","INDEL"),
        Tool_ID = names(fileToolList)[i],
        stringsAsFactors = FALSE
      )
      file_pass <- rbind(file_pass, site_temp)

      all_sites[[k]] <- file_pass
      k = k+1
    }
  }
  newL <- list(all_sites = all_sites, ind = k)
  return(newL)
}
