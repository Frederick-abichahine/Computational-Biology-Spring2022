#' Clustering of matrix
#'
#' @param matrix matrix to cluster
#' @return matrix clustered

clustering_matrix <- function(matrix){

  h_ord <- hclust(dist(matrix))
  matrix <- matrix[h_ord$order, ]
  matrix <- matrix[,match(rownames(matrix), colnames(matrix))]
  return(matrix)
}


