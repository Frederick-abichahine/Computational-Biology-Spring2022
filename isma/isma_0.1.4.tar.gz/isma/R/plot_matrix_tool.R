#' Plot similarity matrix
#'
#' @param ov_samples_sites similarity matrix obtained from overlap_Tools

plot_matrix_tool <- function(ov_samples_sites){
  par(mar=c(6,6, 1, 1))
  rotate <- function(x) t(apply(x, 2, rev))
  ov_samples_1 <- ov_samples_sites
  ov_samples_2 <- ov_samples_sites


  #plot ratio
  ov_samples_2[lower.tri(ov_samples_2)] <- NA
  diag(ov_samples_2) <- NA
  ov_samples_2_txt <- round( ov_samples_2,2)
  ntool <- dim(ov_samples_2)[1]
  ijpairs <- t(combn(ntool , 2))
  # ov_samples_2 <- log(ov_samples_1+1
  image(rotate(ov_samples_2), col= brewer.pal(n = 6, "Purples"), xaxt="none", yaxt="none")
  grid(ncol(ov_samples_sites), nrow(ov_samples_sites), lty=1, lwd=1)
  axis(1, seq(0, nrow(ov_samples_sites)-1, length.out = nrow(ov_samples_sites))/(ncol(ov_samples_sites)-1), colnames( ov_samples_sites), las=2, cex.axis=0.8)
  axis(2, seq(0, nrow(ov_samples_sites)-1, length.out = nrow(ov_samples_sites))/(ncol(ov_samples_sites)-1), rev(rownames( ov_samples_sites)), las=2, cex.axis=0.8)
  xx <- seq(0, 1, length.out = ncol(ov_samples_sites))
  yy <- seq(0, 1, length.out = nrow(ov_samples_sites))
  ov_samples_2_txt <- rotate(ov_samples_2_txt)
  for(i in 1:nrow(ov_samples_2_txt)){
    for(j in 1:ncol(ov_samples_2_txt)){
      if(!is.na(ov_samples_2_txt[i,j])){
        text((i-1)/(nrow(ov_samples_2_txt)-1), (j-1)/(ncol(ov_samples_2_txt)-1), ov_samples_2_txt[i, j], cex=1)
      }
    }
  }

  #plot co-occurence
  ov_samples_1[upper.tri(ov_samples_1)] <- NA
  ov_samples_1_txt <- round(ov_samples_1,0)
  ov_samples_1 <- log(ov_samples_1+1)
  par(mar=c(5,5, 1, 1))
  image(rotate(ov_samples_1), col=brewer.pal(n = 7, "Blues"), xaxt="none", yaxt="none", add=T)
  grid(ncol(ov_samples_sites), nrow(ov_samples_sites), lty=1, lwd=1)
   ov_samples_1_txt <- rotate(ov_samples_1_txt)
   for(i in 1:nrow(ov_samples_1_txt)){
    for(j in 1:ncol(ov_samples_1_txt)){
      if(!is.na(ov_samples_1_txt[i,j])){
     text((i-1)/(nrow(ov_samples_1_txt)-1), (j-1)/(ncol(ov_samples_1_txt)-1), round(ov_samples_1_txt[i, j],0), cex=1)
      }
    }
  }



}
