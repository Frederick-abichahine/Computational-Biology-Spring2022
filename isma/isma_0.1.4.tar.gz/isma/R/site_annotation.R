#' Perform site annotation
#'
#' @param all.sites.methods  data.frame produced by pre_process or get_TCGA_sites functions
#' @param Consequence TRUE/FALSE, if TRUE, consequence is given also for coding sites; it requires additional arguments (see below)
#' @param file_VCF VCF file name, produced throught  `save_VCF_for_annotation`, only if consequence=TRUE
#' @param genome hg19, hg38
#' @param reference_fasta genome reference file in fasta format, only if consequence=TRUE
#'
#' @return data.frame with the annotated sites
#' @import VariantAnnotation
#' @import TxDb.Hsapiens.UCSC.hg19.knownGene
#' @import TxDb.Hsapiens.UCSC.hg38.knownGene
#' @importFrom SummarizedExperiment rowRanges
#' @importFrom Rsamtools FaFile
#' @export

site_annotation <- function(all.sites.methods, genome, Consequence = FALSE, file_VCF, reference_fasta){

  if(Consequence == TRUE){
    miss <- array()
    if(missing(genome) | missing(file_VCF) | missing(reference_fasta)){
      Consequence = FALSE
      cat("Warnings: Consequence will be set to FALSE because could not find: ")
      if (missing(file_VCF)) {miss <- cat("file_VCF ")}
      if (missing(genome)) {cat("genome ")}
      if (missing(reference_fasta)) {cat("reference_fasta ")}
    }
  }


  if(genome=="hg19"){
    txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene
  }else if(genome=="hg38"){
    txdb <- TxDb.Hsapiens.UCSC.hg38.knownGene
  }

  exon_columns <- columns(txdb)
  exon_columns <- exon_columns[which(exon_columns %in% c("EXONID", "EXONNAME", "GENEID"))]
  all_exons <- exons(txdb, columns = exon_columns)

  gr <-  GRanges(seqnames = all.sites.methods$CHROM, ranges = IRanges(as.numeric(all.sites.methods$POS), as.numeric(all.sites.methods$POS)), strand = "*")
  gr_var <- locateVariants(gr, txdb, AllVariants(), ignore.strand = T)

  #data frame with annotated locations
  temp <- data.frame(
    CHROM = as.character(gr_var@seqnames),
    POS = gr_var@ranges@start,
    Location = as.character(gr_var@elementMetadata@listData$LOCATION),
    locstart = gr_var@elementMetadata@listData$LOCSTART,
    locend = gr_var@elementMetadata@listData$LOCEND,
    txid = gr_var@elementMetadata@listData$TXID,
    Gene = gr_var@elementMetadata@listData$GENEID,
    stringsAsFactors = FALSE
  )

  temp <- unique(temp)


  #merge annotations with initial data
  all.sites.methods <- merge(all.sites.methods, temp, by = c('CHROM', 'POS'), sort = FALSE, all.x = T)

  #add gene symbol
  #all.sites.methods<- merge(all.sites.methods, gene.info.HsRnMmCf[, c('gene_id', 'symbol')], by='gene_id', sort=F, all.x=T)

  coding_site <- all.sites.methods[grep('coding', all.sites.methods$Location), ]
  #Extract noncoding site
  non.coding_site <- all.sites.methods[-grep('coding', all.sites.methods$Location), ]
  if(nrow(non.coding_site)!=0){
    non.coding_site <- cbind(non.coding_site[,!names(non.coding_site) %in% "Location"],
                             Consequence = non.coding_site$Location,
                             Location = ifelse(is.na(non.coding_site$Location), NA, "noncoding")
    )
  }

  if(Consequence==TRUE){
    vcf <- readVcf(file_VCF, genome)
    rd <- rowRanges(vcf)
    altallele <- alt(vcf)
    eltlen <- elementNROWS(altallele)
    rd_exp <- rep(rd, eltlen)
    coding <- predictCoding(rd_exp, txdb, FaFile(reference_fasta), unlist(altallele))
    Site_ID.Conseq<- data.frame(Site_ID = names(coding),
                                Consequence = coding@elementMetadata$CONSEQUENCE)
    Site_ID.Conseq <- unique(Site_ID.Conseq[,c("Site_ID", "Consequence")])
    coding_site <- merge(Site_ID.Conseq, coding_site, by = "Site_ID", all.y = T)
  } else if(Consequence==FALSE){
    coding_site$Consequence <- rep("coding",nrow(coding_site))
  }
  #all.SNP = coding + noncoding
  if(nrow(coding_site)!=0 & nrow(non.coding_site)!=0){
    all.Site <- rbind(coding_site, non.coding_site)
  }else if(nrow(coding_site)!=0) {
    all.sites.methods <- coding_site
  }else if(nrow(non.coding_site)!=0){
    all.sites.methods <- non.coding_site
  }

  all.sites.methods <- all.Site[!duplicated(all.Site[,c("SiteID_Subject",'Tool_ID', "Gene")]), ]

  return(all.sites.methods)
}
