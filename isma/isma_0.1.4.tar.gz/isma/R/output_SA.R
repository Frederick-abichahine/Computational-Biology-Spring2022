#' List of some output of site_analysis
#'
#' @format data.frame
"output_SA"
