#' Read and integrate input files; generate unique identifiers
#'
#' @param filename configuration file name
#' @return data.frame integrating input files with unique identifiers of Sites; Site and Subject; Site, Subject and Tool_ID
#' @export
#' @importFrom utils read.table


pre_process <- function(filename){

  fileList <- read.table(filename, sep="\t",header=TRUE, stringsAsFactors = FALSE, na.strings = "-")
  fileToolList <- split(fileList$File,fileList$Tool_ID)
  all_sites <- vector('list', dim(fileList)[1])
  k=1
  nucl<-c("A","C","G","T")
  for(i in 1:length(fileToolList)){
    cat(i)
    switch(names(fileToolList)[i],
           #MUTECT 1
           mutect1 = {
             listOutput <- mutect(fileToolList, fileList, i, k, all_sites)
             all_sites <- listOutput$all_sites
             k<-listOutput$ind
           },
           mutect2 = {
             listOutput <- mutect(fileToolList, fileList, i, k, all_sites)
             all_sites <- listOutput$all_sites
             k<-listOutput$ind
           },
           varscan2={
             listOutput<- varscan(fileToolList, fileList, i, k, all_sites)
             all_sites <- listOutput$all_sites
             k<-listOutput$ind
           },
           muse = {
             listOutput<- muse(fileToolList, fileList, i, k, all_sites)
             all_sites <- listOutput$all_sites
             k<-listOutput$ind
           },
           somsnip = {
             listOutput<- somaticSniper(fileToolList, fileList, i, k, all_sites,nucl)
             all_sites <- listOutput$all_sites
             k<-listOutput$ind
           },
           strelka = {
             listOutput<- strelka(fileToolList, fileList, i, k, all_sites,nucl)
             all_sites <- listOutput$all_sites
             k<-listOutput$ind },
           {
             listOutput<- other_VC(fileToolList, fileList, i, k, all_sites)
             all_sites <- listOutput$all_sites
             k<-listOutput$ind
           }
    )
  }
  all.sites.methods <- do.call(rbind, all_sites)

  #Calculate VAF
  Tumor_Vaf <- ifelse(all.sites.methods$Tumor_var_reads+all.sites.methods$Tumor_ref_reads>0, all.sites.methods$Tumor_var_reads/(all.sites.methods$Tumor_var_reads+all.sites.methods$Tumor_ref_reads), 0)
  Normal_Vaf <- ifelse(all.sites.methods$Normal_ref_reads+all.sites.methods$Normal_var_reads>0, all.sites.methods$Normal_var_reads/(all.sites.methods$Normal_ref_reads+all.sites.methods$Normal_var_reads), 0)

  #Add columns: VAF (Tumor/Normal), REF+ALT (Tumor/Normal), size_INDEL
  all.sites.methods <- data.frame(
    all.sites.methods,
    Tumor_Vaf=Tumor_Vaf,
    Normal_Vaf= Normal_Vaf,
    Tumor_reads=all.sites.methods$Tumor_ref_reads+all.sites.methods$Tumor_var_reads,
    Normal_reads=all.sites.methods$Normal_ref_reads+all.sites.methods$Normal_var_reads,
    size_INDEL=nchar(all.sites.methods$REF)-nchar(all.sites.methods$ALT),
    stringsAsFactors = FALSE
  )
  all.sites.methods <- all.sites.methods[c("CHROM", "POS", "REF", "ALT",
                                           "Variant_Type", "Subject_ID", "Design",
                                           "Tumor_ref_reads", "Tumor_var_reads", "Tumor_reads", "Tumor_Vaf",
                                           "Normal_ref_reads", "Normal_var_reads", "Normal_reads", "Normal_Vaf",
                                           "size_INDEL", "Tool_ID")]

  all.sites.methods <- create_IDs(all.sites.methods)
  idx <- !grepl("chr", all.sites.methods$CHROM)
  all.sites.methods[idx,"CHROM"] <- paste0("chr", all.sites.methods[idx, "CHROM"])
  return(all.sites.methods)
}
