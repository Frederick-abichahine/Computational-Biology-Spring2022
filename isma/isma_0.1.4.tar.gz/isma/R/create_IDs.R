#' Creation of ID for Sites, SiteID_Subject, SiteID_Subject_Tool_ID
#'
#' @param all.sites.methods data.frame with mutation sites
#' @return the initial data.frame with unique identifiers for sites, subjects and tools
#' @importFrom stringr str_split_fixed


create_IDs  <- function(all.sites.methods){


  if("Site_ID" %in% colnames(all.sites.methods)){
    stop("The IDs have already been created!")
  }

  #if sites are annotated they may be duplicated due to genes annotation
  if("Gene" %in% colnames(all.sites.methods)){
    all.sites.methods_BD <- all.sites.methods
    all.sites.methods <- all.sites.methods[!duplicated(all.sites.methods[,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject', 'Tool_ID')]), ]
  }


  #Create Site_ID
  sites_unq <- unique(all.sites.methods[ , c("CHROM", "POS", "REF", "ALT")])
  sites_unq <- data.frame(
    Site_ID=paste0("S", seq(1:nrow(sites_unq))),
    sites_unq,
    stringsAsFactors = F
  )

  #Add column of Site_ID to data.frame with sites
  all.sites.methods <- merge(sites_unq, all.sites.methods, by = c("CHROM", "POS", "REF", "ALT"), sort = F)

  #Create SiteID_Subject
  all.sites.methods <- data.frame(
    all.sites.methods,
    SiteID_Subject = apply(all.sites.methods[ ,c("Site_ID","Subject_ID")], 1, paste, collapse = "_"),
    stringsAsFactors = FALSE
  )

  #Create SiteID_Subject_Tool_ID
  all.sites.methods <- data.frame( all.sites.methods,
                                   SiteID_Subject_Tool_ID  = apply(all.sites.methods[ ,c("SiteID_Subject","Tool_ID")], 1, paste, collapse = "_"),
                                   stringsAsFactors = FALSE
  )
  return(all.sites.methods)
}

