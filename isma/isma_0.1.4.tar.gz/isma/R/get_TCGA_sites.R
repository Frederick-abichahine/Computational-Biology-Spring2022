#' Download somatic mutations from TCGAbiolinks
#'
#' @param tools two or more pipelines
#' @param project project
#' @param n_subjects # subjects
#' @param seed_n TRUE/FALSE, to create simulations that can be reproduced
#' @param barcode vector of barcodes selected by user
#' @return integration of mutated sites from TCGAbiolinks
#' @import TCGAbiolinks
#' @importFrom stringr str_c
#' @export

get_TCGA_sites <- function(tools=c("mutect2", "varscan2", "muse", "somaticsniper"), project="BRCA", n_subjects=NULL, seed_n = NULL, barcode = NULL) {

  #n_subjects or barcode
  if(is.null(n_subjects) & is.null(barcode)){
    stop("You have to define \"n_subjects\" or \"barcode\" variable.")
  }  else if(!is.null(seed_n) & is.null(n_subjects)){ #if define seed you have to define the number of subjects
    stop("You have to define the variable \"n_subjects\"")
  } else if(!is.null(n_subjects) & !is.null(barcode)){ #n_subjects or barcodes
    stop("You can't use \"n_subjects\" and \"barcode\" variables together.")
  } else if(!is.null(seed_n) & !is.null(n_subjects) & !is.null(barcode)){ #n_subjects/seed_n or barcodes
    stop("You can't use \"seed_n\", \"n_subjects\", \"barcode\" variables together.")
  } else if(!is.null(seed_n) & is.null(barcode)){
    variab_flag = 1 #generate dataset that can be reproduced
    cat(paste0("n_subjects = ", n_subjects, ", seed_n = ", seed_n))
  } else if(is.null(seed_n) & !is.null(barcode)){
    variab_flag = 2 #use selected barcodes
  } else if(is.null(seed_n) & is.null(barcode)){
    variab_flag = 3 #generate random dataset
    cat(paste0("n_subjects = ", n_subjects))
  }



  sites <- vector("list", length(tools))

  if("mutect2" %in% tools){
    sites$mutect2 <- GDCquery_Maf(project, pipelines = "mutect2")
    sites$mutect2$Tool_ID <- "mutect2"
  }
  if("varscan2" %in% tools){
    sites$varscan2 <- GDCquery_Maf(project, pipelines = "varscan2")
    sites$varscan2$Tool_ID <- "varscan2"
  }
  if("muse" %in% tools){
    sites$muse <- GDCquery_Maf(project, pipelines = "muse")
    sites$muse$Tool_ID <- "muse"
  }
  if("somaticsniper" %in% tools){
    sites$somaticsniper <- GDCquery_Maf(project, pipelines = "somaticsniper")
    sites$somaticsniper$Tool_ID <- "somaticsniper"
  }

  sites <- do.call(rbind, sites)

  #common participants
  part_tool <- split(sites$Tumor_Sample_Barcode, sites$Tool_ID)
  part_tool <- lapply(part_tool, unique)
  common_part <- part_tool[[1]][part_tool[[1]] %in% part_tool[[2]]]
  if(length(part_tool) > 2){
    for(i in 3:length(part_tool)){
      common_part <- part_tool[[i-1]][part_tool[[i-1]] %in% part_tool[[i]]]
    }
  }

  rm(part_tool)
  if(variab_flag ==1){
    set.seed(seed_n)
    sampleShare <- sample(common_part, n_subjects)
    rm(common_part)
    sites <- sites[which(sites$Tumor_Sample_Barcode %in% sampleShare), ]
  } else if(variab_flag == 2){
    sites <- sites[which(sites$Tumor_Sample_Barcode %in% common_part), ]
    vect_b <- setdiff(barcode,sites$Tumor_Sample_Barcode)

    if(length(vect_b)>0){
      stop(paste0("Barcode: ",str_c(vect_b, collapse=",")," are not reported in TCGA data"))
    }
    sites <- sites[which(sites$Tumor_Sample_Barcode %in% barcode), ]
  } else if(variab_flag == 3){
    sampleShare <- sample(common_part, n_subjects)
    rm(common_part)
    sites <- sites[which(sites$Tumor_Sample_Barcode %in% sampleShare), ]
  }

  #Extract from Tumor_Sample_Barcode the Participant identifier
  subject <- process_TCGA_barcodes(sites$Tumor_Sample_Barcode)$Participant

  sites <- data.frame(sites, Subject_ID = subject, stringsAsFactors = F)

  #Extract the interested column
  sites <- data.frame(sites[, c("Chromosome","Start_Position","Reference_Allele", "Tumor_Seq_Allele2", "t_ref_count", "t_alt_count", "n_depth", "n_ref_count", "n_alt_count", "Subject_ID", "Variant_Type", "Tool_ID")], Design ="WXS", stringsAsFactors = F)

  #Rename column
  colnames(sites) <- c("CHROM", "POS", "REF", "ALT", "Tumor_ref_reads", "Tumor_var_reads","Normal_reads", "Normal_ref_reads", "Normal_var_reads", "Subject_ID", "Variant_Type", "Tool_ID", "Design")

  sites$Variant_Type <- ifelse(sites$Variant_Type=="SNP", "SNP", "INDEL")

  #Add other column required by ISMA
  sites <- data.frame(sites,
                      Tumor_reads = sites$Tumor_ref_reads+sites$Tumor_var_reads,
                      Tumor_Vaf = sites$Tumor_var_reads/(sites$Tumor_ref_reads+sites$Tumor_var_reads),
                      Normal_Vaf = NA,
                      size_INDEL = ifelse(sites$REF=="-", 0, nchar(sites$REF))-ifelse(sites$ALT=="-", 0, nchar(sites$ALT)),
                      stringsAsFactors = FALSE
  )

  sites <-  sites[, c("CHROM", "POS", "REF", "ALT",
                                  "Variant_Type", "Subject_ID", "Design",
                                  "Tumor_ref_reads", "Tumor_var_reads", "Tumor_reads", "Tumor_Vaf",
                                  "Normal_ref_reads", "Normal_var_reads", "Normal_reads", "Normal_Vaf",
                                  "size_INDEL", "Tool_ID")]
  sites <- create_IDs(sites)
  return(sites)
}
