#' Read standardized matrix of Variant callers
#'
#' @param fileToolList List of files separated by tools
#' @param fileList  list with all files and informations
#' @param i Index of fileToolList
#' @param k Index of the iteration
#' @param all_sites Empty list in which will be save the mutation sites
#'
#' @importFrom utils read.table

other_VC <- function(fileToolList, fileList, i, k, all_sites){

  for (j in 1:length(fileToolList[[i]])){

    file <- read.table(fileToolList[[i]][j], header = TRUE, stringsAsFactors = FALSE)

    file_compl <- cbind(file[,c("CHROM","POS","REF","ALT")],
                        Design = fileList$Design[fileToolList[[i]][j]==fileList$File],
                        file[,c("Tumor_ref_reads","Tumor_var_reads","Normal_ref_reads","Normal_var_reads")],
                        Subject_ID = fileList$Subject_ID[fileToolList[[i]][j]==fileList$File],
                        Variant_Type = ifelse((sapply(file$REF, function(x) length(unlist(strsplit(x, "")))) + sapply(file$ALT, function(x) length(unlist(strsplit(x, ""))))==2),"SNP","INDEL"),
                        Tool_ID = names(fileToolList)[i],
                        stringsAsFactors = FALSE
    )
    all_sites[[k]] <- file_compl
    k=k+1}
  newL <- list(all_sites = all_sites, ind = k)
  return(newL)
}


