#' Calculate subject-by-subject site/gene co-occurrence matrix.
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param Tool_ID tools to take into account
#' @param type Site or Gene
#' @param cores number of cores to use
#' @importFrom utils combn
#' @importFrom igraph get.adjacency
#' @importFrom igraph graph.data.frame
#' @importFrom grDevices dev.off heat.colors jpeg
#' @importFrom graphics axis image par text
#' @importFrom stats dist hclust
#' @return a matrix with amount of shared sites/genes among Subjects, standard deviation
#' @export


overlap_Subjects <- function(all.sites.methods, Tool_ID = NULL, type = NULL, cores=NULL){


  #Controls
  if(is.null(type)){
    stop("You have to define type. The options are: \"Site\" or \"Gene\".")
  }

  if(type=="Gene" & !"Gene" %in% colnames(all.sites.methods)){
    stop("The sites are not annotated! You should use: \"type = Site\"")
  }

  if(!"Site_ID" %in% colnames(all.sites.methods)){
    stop("The ID were not created: use create_IDs before!")
  }

  #if Tool_IDs are not specified all tools are used
  if(is.null(Tool_ID)){
    Tool_ID <- unique(all.sites.methods$Tool_ID)
  }else if(!is.null(Tool_ID)){
    Tool_ID_uniq <- unique(all.sites.methods$Tool_ID)
    temp <- setdiff(Tool_ID, Tool_ID_uniq)
    if(length(temp)>0){
      stop(sprintf(paste("Wrong Tool_ID: ", temp, ".")))
    }
  }

  Subject_ID <- unique( all.sites.methods$Subject_ID)
  #switch for type of analysis
  switch(type,
         "Site"={
           #if sites are annotated they may be duplicated due to genes annotation
           all.sites.methods <- all.sites.methods[!duplicated(all.sites.methods[,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject', 'Tool_ID')]), ]
           #create a list where each element is the matrix subject x subject obtained for each tool
           list_overlap <- vector('list', length(Tool_ID))
           all.sites.methods$Subject_ID <- as.factor(all.sites.methods$Subject_ID)
           for(k in 1:length(Tool_ID)){
             #extract sites of k-th tool
             temp <- all.sites.methods[which(all.sites.methods$Tool_ID==Tool_ID[k]),]

             #Calculate table siteID x Subject_ID, 1 the site is mutated in the the Subject, otherwise 0
             tableM <- as.data.frame.ts(sign(t(table(temp$Subject_ID, temp$Site_ID))))
             overlapSubjects <- occ_Sub(temp,tableM, cores)
             overlapSubjects <- overlapSubjects[,match(Subject_ID,colnames(overlapSubjects))]
             overlapSubjects<- overlapSubjects[match(Subject_ID,rownames(overlapSubjects)),]
             list_overlap[[k]] <- overlapSubjects
           }
           names(list_overlap) <- c(Tool_ID)
           n_Subject <- length(Subject_ID)
           dim_sub <- (n_Subject)^2
           #calculate stdev, mean and CV
           f_sd <- function(lst) { n <- length(lst); rc <- dim(lst[[1]]); ar1 <- array(unlist(lst), c(rc, n)); round(apply(ar1, c(1, 2), sd), 2); }
           stdev_m <- f_sd(list_overlap)
           colnames(stdev_m) <- (Subject_ID)
           rownames(stdev_m) <- (Subject_ID)
           f_mean <- function(lst) { n <- length(lst); rc <- dim(lst[[1]]); ar1 <- array(unlist(lst), c(rc, n)); round(apply(ar1, c(1, 2), mean), 2); }
           mean_m <- f_mean(list_overlap)
           colnames(mean_m) <- (Subject_ID)
           rownames(mean_m) <- (Subject_ID)
           list_overlap$stdev_m <-stdev_m
           list_overlap$mean_matrices <- mean_m
           #calculate coefficient of variation
           cv <- stdev_m/mean_m
           list_overlap$cv <- cv
           ###All tool
           temp <- all.sites.methods[which(all.sites.methods$Tool_ID %in% Tool_ID), ]
           #considere the combination of pairs subject-ith and subject-jth
           tableM <- as.data.frame.ts(sign(t(table(temp$Subject_ID, temp$Site_ID))))
           #considere the combination of pairs subject-ith and subject-jth
           overlapSubjects <- occ_Sub(temp, tableM, cores)
           list_overlap$All <- overlapSubjects
         },
         "Gene"={
           #create a list where each element is the matrix subject x subject obtained for each tool
           list_overlap <- vector('list', length(Tool_ID))
           all.sites.methods$Subject_ID <- as.factor(all.sites.methods$Subject_ID)
           for(k in 1:length(Tool_ID)){
             #extract genes of k-th tool
             temp <- all.sites.methods[which(all.sites.methods$Tool_ID==Tool_ID[k]),]
             #Calculate table siteID x Subject_ID, 1 the gene is mutated in the the Subject, otherwise 0
             tableM <- sign(as.data.frame.ts(table(temp$Gene, temp$Subject_ID)))
             overlapSubjects<- occ_Sub(temp, tableM, cores)
             overlapSubjects <- overlapSubjects[,match(Subject_ID,colnames(overlapSubjects))]
             overlapSubjects<- overlapSubjects[match(Subject_ID,rownames(overlapSubjects)),]
             list_overlap[[k]] <- overlapSubjects
           }
           names(list_overlap) <- c(Tool_ID)
           n_Subject <- length(unique( all.sites.methods$Subject_ID))
           dim_sub <- (n_Subject)^2
           #calculate stdev
           #calculate stdev, mean and CV
           f_sd <- function(lst) { n <- length(lst); rc <- dim(lst[[1]]); ar1 <- array(unlist(lst), c(rc, n)); round(apply(ar1, c(1, 2), sd), 2); }
           stdev_m <- f_sd(list_overlap)
           colnames(stdev_m) <- (Subject_ID)
           rownames(stdev_m) <- (Subject_ID)
           f_mean <- function(lst) { n <- length(lst); rc <- dim(lst[[1]]); ar1 <- array(unlist(lst), c(rc, n)); round(apply(ar1, c(1, 2), mean), 2); }
           mean_m <- f_mean(list_overlap)
           colnames(mean_m) <- (Subject_ID)
           rownames(mean_m) <- (Subject_ID)
           list_overlap$stdev_m <-stdev_m
           list_overlap$mean_matrices <- mean_m
           #calculate coefficient of variation
           cv <- stdev_m/mean_m
           list_overlap$cv <- cv
           ###All tool
           temp <- all.sites.methods[which(all.sites.methods$Tool_ID %in% Tool_ID), ]
		       tableM <- sign(as.data.frame.ts(t(table(temp$Subject_ID, temp$Gene))))
		       overlapSubjects <- occ_Sub(temp, tableM, cores)
           list_overlap$All <- overlapSubjects
         },
         {stop(sprintf(paste("Wrong type: ", type, ", please use: Site or Gene.")))
         }
  )
  return(list_overlap)
}
