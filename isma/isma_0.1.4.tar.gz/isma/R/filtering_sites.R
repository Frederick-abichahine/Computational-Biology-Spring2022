#' Filtering the sites matrix
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param file_filtering  file with the choosen filtering criteria

#' @return integrated mutation sites data.frame with a new colum reporting information of filtering status 1/0
#' @export
#' @importFrom utils read.table

filtering_sites <- function(all.sites.methods, file_filtering){

  filt <- read.table(file_filtering, header = TRUE, stringsAsFactors = FALSE)
  logicVector <- filt$Filtering_parameter %in% colnames(all.sites.methods)
  temp <- filt$Filtering_parameter[!(logicVector)]
  if(length(temp)>0){
    warning(paste0("Miss the following column for filtering because not present: ", paste0(temp, collapse=" ")))
  }
  filt <- filt[logicVector, ]
  logicColumnPresence <- unlist(apply(all.sites.methods[as.character(filt$Filtering_parameter)], 2, function(x) any(!is.na(x))))
  temp <- filt$Filtering_parameter[!(logicColumnPresence)]
  if(length(temp)>0){
    warning(paste0("Miss the following column for filtering because the values are \"NA\": ", paste0(temp, collapse=" ")))
  }
  filt <- filt[logicColumnPresence, ]
  sites <- nrow(all.sites.methods)

  all.sites.methodsBF <- all.sites.methods
  for(i in 1:dim(filt)[1]){
    switch(filt$Operator[i],
           "<="={
             all.sites.methods <- all.sites.methods[abs(all.sites.methods[filt[i,1]]) <= filt[i,2],]  },
           ">="={
             all.sites.methods <- all.sites.methods[abs(all.sites.methods[filt[i,1]]) >= filt[i,2],]  },
           "=="={
             all.sites.methods <- all.sites.methods[abs(all.sites.methods[filt[i,1]]) == filt[i,2],]  },
           "!="={
             all.sites.methods <- all.sites.methods[abs(all.sites.methods[filt[i,1]]) != filt[i,2],]  },
           ">"={
             all.sites.methods <- all.sites.methods[abs(all.sites.methods[filt[i,1]]) > filt[i,2],]  },
           "<"={
             all.sites.methods <- all.sites.methods[abs(all.sites.methods[filt[i,1]]) < filt[i,2],]  },
           {
             stop(sprintf(paste("Wrong Operator: ", filt$Operator[i], ", please use: <=, <, ==, >, >=, !=" )))
           }
    )
  }
  all.sites.methodsBF$Filter <- ifelse(all.sites.methodsBF$SiteID_Subject_Tool_ID  %in% all.sites.methods$SiteID_Subject_Tool_ID , 1, 0)
  sitesFilt <- nrow(all.sites.methods)
  print(paste("Initial Sites: ", sites, " Sites passed filtering criteria: ", sum(all.sites.methodsBF$Filter)))
  return(all.sites.methodsBF)
}

