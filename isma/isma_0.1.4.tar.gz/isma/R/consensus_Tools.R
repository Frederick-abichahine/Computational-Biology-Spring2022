#' Calculation of consensus among tools
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param filename string with path, file name, and format for saving a barplot with the consensus among tools
#' @param ... Arguments to be passed to methods, such as graphical parameters
#' @return the input with a new column reporting the number of tools supported the called site.
#' @importFrom gplots venn
#' @importFrom stringr str_split_fixed
#' @importFrom stats na.omit
#' @importFrom grDevices dev.off jpeg
#' @importFrom graphics barplot
#' @export

consensus_Tools  <- function(all.sites.methods, filename = NULL, ...){


  #List of Subject_ID
  if("n_Tools" %in% colnames(all.sites.methods)){
    all.sites.methods <- all.sites.methods[, !colnames(all.sites.methods)=="n_Tools"]
  }

  #if sites are annotated they may be duplicated due to genes annotation
  if("Gene" %in% colnames(all.sites.methods)){
    all.sites.methods_BD <- all.sites.methods
    all.sites.methods <- all.sites.methods[!duplicated(all.sites.methods[,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject', 'Tool_ID')]), ]
  }

  if(!"Site_ID" %in% colnames(all.sites.methods)){
    stop("The ID were not created: use create_IDs before!")
  }

  #Library gplot to calculate overlap
  tab <- venn(data=split(all.sites.methods$SiteID_Subject, all.sites.methods$Tool_ID), show.plot = FALSE)

  #Ovelarp
  intTool <- attr(tab,"intersections")
  tableCount3  <- data.frame()
  inters <- sapply(names(intTool), function(x) length(unlist(strsplit(x, ":"))))

  #Create Table 3 : ID_Site.Subject, # Tool_shared

  for(i in 1:length(intTool)){
    siteShar <- data.frame(
      SiteID_Subject = intTool[[i]],
      n_Tools = rep(inters[i], length(intTool[[i]])),
      stringsAsFactors = FALSE)
    tableCount3 <- rbind(tableCount3, siteShar)
  }

  #Add column of n_Tool supporting sites
  if("Gene" %in% colnames(all.sites.methods)){
    all.sites.methods <- merge(all.sites.methods_BD, tableCount3[,c("SiteID_Subject","n_Tools")], by = "SiteID_Subject")
  }else{
    all.sites.methods <- merge(all.sites.methods, tableCount3[,c("SiteID_Subject","n_Tools")], by = "SiteID_Subject")
  }

  sites_uniq <- all.sites.methods[!duplicated(all.sites.methods[,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject', 'Tool_ID')]), ]

  if(!is.null(filename)){
    jpeg(filename, ...)
    barplot(table(sites_uniq$n_Tools), xlab="# tool supporting sites", ylab="# sites")
    dev.off()
  }
  return(all.sites.methods)
}
