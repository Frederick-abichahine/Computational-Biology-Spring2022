#' An example of custom input format 
#'
#' @format tab-delimited files (8 columns)
"custom_format_example"
