#' Calculates the co-occurrence of mutation sites/genes across callers and subjects.
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param type Site or Gene
#' @param filename string with path, file name, and format for saving an image with results
#' @param ... Arguments to be passed to methods, such as graphical parameters
#' @return list with the following elements:
#' \itemize{
#' \item{var_per_subject: data.frame with the number of SNP and INDEL for each Subject_ID and Tool_ID;}
#' \item{subjects_per_var: data.frame with the number of Subjects supporting mutation sites;}
#' \item{tool_per_var: data.framte with the number of tools supporting Subject_Sites;}
#' }
#' @importFrom gplots venn
#' @importFrom stringr str_split_fixed
#' @importFrom stats na.omit
#' @importFrom grDevices dev.off jpeg
#' @importFrom graphics plot barplot
#' @export

get_sites_statistics  <- function(all.sites.methods, type = NULL, filename = NULL, ...){


  ##Control
  if(is.null(type)){
    stop("You have to define type. The options are: \"Site\" or \"Gene\".")
  }

  if(type=="Gene" & !"Gene" %in% colnames(all.sites.methods)){
    stop("The sites are not annotated! You should use: \"type = Site\"")
  }

  if(!"Site_ID" %in% colnames(all.sites.methods)){
    stop("The ID were not created: use create_IDs before!")
  }

  if(!"n_Tools" %in% colnames(all.sites.methods)){
    stop("The consensus among tools were not calculated: use consensus_Tools before!")
  }

  if(nrow(all.sites.methods)==0){
    stop("Empty input")
  }
  switch(type,
         "Site"={
           #if sites are annotated they may be duplicated due to genes annotation
           if("Gene" %in% colnames(all.sites.methods)){
             all.sites.methods_BD <- all.sites.methods
             all.sites.methods <- all.sites.methods[!duplicated(all.sites.methods[,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject', 'Tool_ID')]), ]
           }

           #Calculate number of mutated sites for each subject
           Subject_ID <- unique(all.sites.methods$Subject_ID)
           all.sites.methods$Tool_ID <- as.factor(all.sites.methods$Tool_ID)
           countTOT <- table(all.sites.methods$Subject_ID, all.sites.methods$Tool_ID)
           #Extract INDEL mutation sites
           sites.INDEL <- all.sites.methods[all.sites.methods$Variant_Type == "INDEL", ]
           #Count for each tool and each Subject the total numbers of INDEL (using the dimensions of the resulted split)
           if(nrow(sites.INDEL) >0){
           countINDEL <-  table(sites.INDEL$Subject_ID, sites.INDEL$Tool_ID)
           } else {
             countINDEL <- 0
           }

           #Extract SNV mutation sites
           sites.SNP <- all.sites.methods[all.sites.methods$Variant_Type == "SNP", ]
           #Count for each tool and each Subject the total numbers of SNV (using the dimensions of the resulted split)
           if(nrow(sites.SNP) >0){
               countSNP <-  table(sites.SNP$Subject_ID, sites.SNP$Tool_ID)
             } else {
             countSNP <- 0
           }

           #Create Table 1 : Subject_ID, Tool_ID, # Sites, Type (All/SNP/INDEL)

           tableCount1_TOT <- data.frame()
           if(is.table(countTOT)){
             for(i in 1:dim(countTOT)[1]){
               for(j in 1:dim(countTOT)[2]){
                 temp <- data.frame(
                   Subject_ID = rownames(countTOT)[i],
                   Tool_ID = colnames(countTOT)[j],
                   Sites = countTOT[i,j],
                   Type = "All",
                   stringsAsFactors = FALSE)
                   tableCount1_TOT <- rbind(tableCount1_TOT , temp)
               }
             }
           }

           tableCount1_SNP <- data.frame()
           if(is.table(countSNP)){
             for(i in 1:dim(countSNP)[1]){
               for(j in 1:dim(countSNP)[2]){
                 temp <- data.frame(
                   Subject_ID = rownames(countSNP)[i],
                   Tool_ID = colnames(countSNP)[j],
                   Sites = countSNP[i,j],
                   Type = "SNP",
                   stringsAsFactors = FALSE)
                 tableCount1_SNP <- rbind(tableCount1_SNP , temp)
               }
             }
           }


           tableCount1_INDEL <- data.frame()
           if(is.table(countINDEL)){
             cat("ciao")
             for(i in 1:dim(countINDEL)[1]){
               for(j in 1:dim(countINDEL)[2]){
                 temp <- data.frame(
                   Subject_ID = rownames(countINDEL)[i],
                   Tool_ID = colnames(countINDEL)[j],
                   Sites = countINDEL[i,j],
                   Type = "SNP",
                   stringsAsFactors = FALSE)
                 tableCount1_INDEL <- rbind(tableCount1_INDEL , temp)
               }
             }
           }
           tableCount1 <- rbind(tableCount1_TOT, tableCount1_SNP, tableCount1_INDEL)


           #Calculate number of subject supporting site
           countID_SITE.Subject <- sapply(split(all.sites.methods[!duplicated(all.sites.methods[,c('Site_ID', 'Subject_ID')]), ]$Subject_ID, all.sites.methods[!duplicated(all.sites.methods[ ,c('Site_ID', 'Subject_ID')]),]$Site_ID), function(x) length(x))

           #Create Table 2 : Site_ID, #Subject supporting the mutation sites
           tableCount2 <- data.frame(
             Site_ID = names(countID_SITE.Subject),
             Subject = countID_SITE.Subject,
             stringsAsFactors = FALSE
           )

           #Create Table 3: SiteID_Subject, Site_ID, Subject_ID , #tools supporting site
           tableCount3 <- unique(all.sites.methods[,c("SiteID_Subject","Site_ID","Subject_ID","n_Tools")])

           rownames(tableCount1) <- NULL
           rownames(tableCount2) <- NULL
           rownames(tableCount3) <- NULL

           #Create Table 4: Site_ID, Subject_ID, Tool_ID, #tools supporting site
           tableCount4 <- all.sites.methods[, c("Site_ID", "Subject_ID", "Tool_ID", "n_Tools")]
           #create a list with results
           listOutput <- list(tableCount1, tableCount2, tableCount3, tableCount4)
           names(listOutput) <- c("var_per_subject", "subjects_per_var", "tool_per_var", "consensus_tool")
         },

         "Gene"={
           #eliminate gene without identifier
           temp_all.sites.methods <- all.sites.methods[!is.na(all.sites.methods$Gene),]
           #eliminate gene duplicated by Subject_ID and Tool_ID
           temp_all.sites.methods <- temp_all.sites.methods[!duplicated(temp_all.sites.methods[,c("Gene","Subject_ID","Tool_ID")]),]
           Subject_ID <- as.character(unique(temp_all.sites.methods$Subject_ID))
           #Calculate number of mutated genes for each subject
           #Calculate number of mutated sites for each subject
           Subject_ID <- unique(all.sites.methods$Subject_ID)
           all.sites.methods$Tool_ID <- as.factor(all.sites.methods$Tool_ID)
           countTOT <- table(all.sites.methods$Subject_ID, all.sites.methods$Tool_ID)
           #Extract INDEL mutation sites
           sites.INDEL <- all.sites.methods[all.sites.methods$Variant_Type == "INDEL", ]
           #Count for each tool and each Subject the total numbers of INDEL (using the dimensions of the resulted split)
           if(nrow(sites.INDEL) >0){
             countINDEL <-  table(sites.INDEL$Subject_ID, sites.INDEL$Tool_ID)
           } else {
             countINDEL <- 0
           }

           #Extract SNV mutation sites
           sites.SNP <- all.sites.methods[all.sites.methods$Variant_Type == "SNP", ]
           #Count for each tool and each Subject the total numbers of SNV (using the dimensions of the resulted split)
           if(nrow(sites.SNP) >0){
             countSNP <-  table(sites.SNP$Subject_ID, sites.SNP$Tool_ID)
           } else {
             countSNP <- 0
           }

           #Create Table 1 : Subject_ID, Tool_ID, # Sites, Type (All/SNP/INDEL)

           tableCount1_TOT <- data.frame()
           if(is.table(countTOT)){
             for(i in 1:dim(countTOT)[1]){
               for(j in 1:dim(countTOT)[2]){
                 temp <- data.frame(
                   Subject_ID = rownames(countTOT)[i],
                   Tool_ID = colnames(countTOT)[j],
                   Gene = countTOT[i,j],
                   Type = "All",
                   stringsAsFactors = FALSE)
                 tableCount1_TOT <- rbind(tableCount1_TOT , temp)
               }
             }
           }

           tableCount1_SNP <- data.frame()
           if(is.table(countSNP)){
             for(i in 1:dim(countSNP)[1]){
               for(j in 1:dim(countSNP)[2]){
                 temp <- data.frame(
                   Subject_ID = rownames(countSNP)[i],
                   Tool_ID = colnames(countSNP)[j],
                   Gene = countSNP[i,j],
                   Type = "SNP",
                   stringsAsFactors = FALSE)
                 tableCount1_SNP <- rbind(tableCount1_SNP , temp)
               }
             }
           }


           tableCount1_INDEL <- data.frame()
           if(is.table(countINDEL)){
             for(i in 1:dim(countINDEL)[1]){
               for(j in 1:dim(countINDEL)[2]){
                 temp <- data.frame(
                   Subject_ID = rownames(countINDEL)[i],
                   Tool_ID = colnames(countINDEL)[j],
                   Gene = countINDEL[i,j],
                   Type = "SNP",
                   stringsAsFactors = FALSE)
                 tableCount1_INDEL <- rbind(tableCount1_INDEL , temp)
               }
             }
           }




           # temp2 <-  lapply(Subject_ID, function(x) sapply(split(temp_all.sites.methods[temp_all.sites.methods$Subject_ID == x, ], temp_all.sites.methods[temp_all.sites.methods$Subject_ID == x, ]$Tool_ID), function(x) length(unique(na.omit(x[,"Gene"])))))
           # tableCount1_TOT <- data.frame()
           # if(is.list(temp2)>0){
           #   for(i in 1:length(Subject_ID)){
           #     temp <- data.frame(
           #       Subject_ID = rep(Subject_ID[i], length(temp2[[i]])),
           #       Tool_ID = names(temp2[[i]]),
           #       Gene = temp2[[i]],
           #       Type = c(rep("All", length(temp2[[i]]))),
           #       stringsAsFactors = FALSE
           #     )
           #     tableCount1_TOT <- rbind(tableCount1_TOT , temp)
           #   }
           # }
           #
           # sites.INDEL <- temp_all.sites.methods[temp_all.sites.methods$Variant_Type == "INDEL", ]
           # #Count for each tool and each Subject the total numbers of INDEL (using the dimensions of the resulted split)
           # if(nrow(sites.INDEL) >0){
           #   countINDEL <- lapply(Subject_ID, function(x) sapply(split(sites.INDEL[sites.INDEL$Subject_ID == x, ], sites.INDEL[sites.INDEL$Subject_ID == x, ]$Tool_ID), function(x) length(unique(na.omit(x[,"Gene"])))))
           # } else {
           #   countINDEL <- 0
           # }
           #
           # tableCount1_INDEL <- data.frame()
           # if(is.list(countINDEL)>0){
           #   for(i in 1:length(Subject_ID)){
           #     temp <- data.frame(
           #       Subject_ID = rep(Subject_ID[i], length(countINDEL[[i]])),
           #       Tool_ID = names(countINDEL[[i]]),
           #       Gene = countINDEL[[i]],
           #       Type = c(rep("INDEL", length(countINDEL[[i]]))),
           #       stringsAsFactors = FALSE
           #     )
           #     tableCount1_INDEL  <- rbind(tableCount1_INDEL , temp)
           #   }
           # }
           #
           # sites.SNP <- temp_all.sites.methods[temp_all.sites.methods$Variant_Type == "SNP", ]
           # if(nrow(sites.SNP) >0){
           #   countSNP <- lapply(Subject_ID, function(x) sapply(split(sites.SNP[sites.SNP$Subject_ID == x, ], sites.SNP[sites.SNP$Subject_ID == x, ]$Tool_ID), function(x) dim(x)[1] ))
           # } else {
           #   countSNP <- 0
           # }
           #
           # tableCount1_SNP <- data.frame()
           #
           # if(is.list(countSNP)>0){
           #   for(i in 1:length(Subject_ID)){
           #     temp <- data.frame(
           #       Subject_ID = rep(Subject_ID[i], length(countSNP[[i]])),
           #       Tool_ID = names(countSNP[[i]]),
           #       Gene = countSNP[[i]],
           #       Type = c(rep("SNP", length(countSNP[[i]]))),
           #       stringsAsFactors = FALSE
           #     )
           #     tableCount1_SNP  <- rbind(tableCount1_SNP , temp)
           #   }
           # }

           tableCount1 <- rbind(tableCount1_TOT, tableCount1_SNP, tableCount1_INDEL)

           #Create Table 2 : Gene, #Subject supporting the mutation sites
           countID_gene.Subject <- sapply(split(temp_all.sites.methods[!duplicated(temp_all.sites.methods[,c('SiteID_Subject', "Gene")]), ]$Subject_ID, temp_all.sites.methods[!duplicated(temp_all.sites.methods[ ,c('SiteID_Subject', "Gene")]),]$Gene), function(x) length(unique(x)))
           tableCount2 <- data.frame(
             Gene = names(countID_gene.Subject),
             Subject = countID_gene.Subject,
             stringsAsFactors = FALSE
           )

           temp <- data.frame( temp_all.sites.methods,
                               Gene_Subject  = apply(temp_all.sites.methods[ ,c("Gene","Subject_ID")], 1, paste, collapse = "_"),
                               stringsAsFactors = FALSE
           )
           #library gplot
           tab <- venn(data=split(temp$Gene_Subject, temp$Tool_ID), show.plot = FALSE)

           #Ovelarp
           intTool <- attr(tab,"intersections")
           tableCount3  <- data.frame()
           inters <- sapply(names(intTool), function(x) length(unlist(strsplit(x, ":"))))

           #Create Table 3 : ID_Site.Subject, # Tool_shared
           for(i in 1:length(intTool)){
             siteShar <- data.frame(
               Gene = sapply(intTool[[i]], function(x)
                 unlist(str_split_fixed(x, "_", 2))[1]),
               Subject_ID = sapply(intTool[[i]], function(x)
                 unlist(str_split_fixed(x, "_", 2))[2]),
               n_Tools = rep(inters[i], length(intTool[[i]])), stringsAsFactors = FALSE)
             tableCount3 <- rbind(tableCount3, siteShar)
           }


           rownames(tableCount1) <- NULL
           rownames(tableCount2) <- NULL
           rownames(tableCount3) <- NULL
           tableCount4 <- all.sites.methods[, c("Site_ID", "Subject_ID", "Tool_ID", "n_Tools")]
           listOutput <- list(tableCount1, tableCount2, tableCount3, tableCount4)
           names(listOutput) <- c("var_per_subject", "subjects_per_var", "tool_per_var", "consensus_tool")

         }, {stop(sprintf(paste("Wrong type: ", type, ", please use: Site or Gene.")))}
  )


  ##########PLOT

  if(!is.null(filename)){
    jpeg(filename,...)
    par(mfrow=c(3,1))
    ###1
    res <- split(listOutput$var_per_subject[listOutput$var_per_subject$Type=="All", c("Tool_ID", "Sites")], listOutput$var_per_subject$Subject_ID[listOutput$var_per_subject$Type=="All"])

    for(i in 1:length(res)){
      rownames(res[[i]]) <- res[[i]]$Tool_ID
      res[[i]]$Tool_ID <- NULL
      colnames(res[[i]]) <- names(res)[i]
    }

    res <- Reduce(cbind, res)
    res <- res[, order(-colSums(res))]
    #barplot: #sites called by each tool in each subject
    barplot(as.matrix(res), las=2, ylab="#sites", legend.text = rownames(res),  args.legend = list(x = "topright",ncol=dim(res)[1], title="Tool"))

    ###2
    res <- table(listOutput$tool_per_var$n_Tools, listOutput$tool_per_var$Subject_ID)
    diff_res <- apply(res,2,function(x) sum(x[2:4])-x[1])
    res <- res[, order(diff_res)]
    #barplot: consensus across tools in each subject
    barplot(as.matrix(res), las=2, beside = T, ylab="#sites", legend.text = TRUE,  args.legend = list(x = "topleft",  title="consensus tools", bty="n", ncol=dim(res)[1]))

    ###3
    tab <- table(listOutput$consensus_tool$n_Tools, listOutput$consensus_tool$Tool_ID)
    #barplot: consensus across tools in each tool
    barplot(tab,las=2, beside = T, legend.text = TRUE, ylab="#sites", args.legend = list(x = "topleft", title="consensus \n tools", bty='n'))
    dev.off()
  }
  return(listOutput)
}
