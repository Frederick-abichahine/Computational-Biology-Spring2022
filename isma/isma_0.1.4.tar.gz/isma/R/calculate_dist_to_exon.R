#' Calculation of mutation site distance from the nearest exon
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param genome hg19 or hg38
#'
#' @return mutation site distance from the nearest exon
#' @import VariantAnnotation
#' @import TxDb.Hsapiens.UCSC.hg19.knownGene
#' @import TxDb.Hsapiens.UCSC.hg38.knownGene
#' @import GenomicRanges
#' @import GenomicFeatures
#' @import IRanges
#' @export

calculate_dist_to_exon <- function(all.sites.methods, genome){
  nrowSites <- nrow(all.sites.methods)
  if(genome=="hg19"){
    txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene
  }else if(genome=="hg38"){
    txdb <- TxDb.Hsapiens.UCSC.hg38.knownGene
  }
  exon_columns <- columns(txdb)
  exon_columns <- exon_columns[which(exon_columns %in% c("EXONID", "EXONNAME", "GENEID"))]
  all_exons <- exons(txdb, columns = exon_columns)
  gr <-  GRanges(seqnames = all.sites.methods$CHROM, ranges = IRanges(as.numeric(all.sites.methods$POS), as.numeric(all.sites.methods$POS)), strand = "*")
  temp <- distanceToNearest(gr, all_exons)
  #Add column reporting the distance to nearest exon
  all.sites.methods <- data.frame(all.sites.methods, dist_to_exon = temp@elementMetadata@listData$distance, stringsAsFactors = F)
  nrowSitesNew <- nrow(all.sites.methods)
  if( nrowSites > nrowSitesNew) warning("Lines' number of output <are less than the input's number")
  return(all.sites.methods)
}
