#' Calculate tool-by-tool site/gene co-occurrence matrix.
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param type Site or Gene
#' @return a list of matrices with the amount of shared sites/genes among Tools in each Subject and considering all subjects together
#' @importFrom utils combn
#' @importFrom igraph get.adjacency
#' @importFrom igraph graph.data.frame
#' @importFrom grDevices heat.colors dev.off jpeg
#' @importFrom graphics axis image par text
#' @importFrom stats dist hclust
#' @export


overlap_Tools <- function(all.sites.methods, type = NULL){

  if(is.null(type)){
    stop("You have to define type. The options are: \"Site\" or \"Gene\".")
  }

  if(type=="Gene" & !"Gene" %in% colnames(all.sites.methods)){
    stop("The sites are not annotated! You should use: \"type = Site\"")
  }

  if(!"Site_ID" %in% colnames(all.sites.methods)){
    stop("The ID were not created: use create_IDs before!")
  }

  Tool_ID <- unique(all.sites.methods$Tool_ID)
  #switch for type of analysis
  switch(type,
         "Site"={
           #if sites are annotated they may be duplicated due to genes annotation
           all.sites.methods <- all.sites.methods[!duplicated(all.sites.methods[,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject', 'Tool_ID')]), ]
           Subject_ID <- as.character(unique(all.sites.methods$Subject_ID))
           #create a list where each element is the matrix tool x tool obtained for each subject
           list_overlap <- vector('list', length(Subject_ID))
           list_overlap_CS <- vector('list', length(Subject_ID))
           all.sites.methods$Tool_ID <- as.factor(all.sites.methods$Tool_ID)
           for(k in 1:length(Subject_ID)){
             #extract data of k-th subject
             temp <- all.sites.methods[which(all.sites.methods$Subject_ID==Subject_ID[k]),]
             uniqueTool_Subject <- unique(temp$Tool_ID)
             #Calculate table siteID x tool, 1 the site is called by tool, otherwise 0
             tableM <- as.data.frame.ts(sign(table(temp$Site_ID, temp$Tool_ID)))
             overlapTool <- occ_Tool(temp, tableM)
             overlapTool_CS <- overlapTool
             overlapTool_CS[upper.tri(overlapTool_CS)] <- t(overlapTool)[upper.tri(overlapTool)]
             list_overlap[[k]] <- overlapTool
             list_overlap_CS[[k]] <- overlapTool_CS
           }

           names(list_overlap) <- c(Subject_ID)
           names(list_overlap_CS)<- c(Subject_ID)
           #All Subjects
           tableM <- as.data.frame.ts(sign(table(all.sites.methods$SiteID_Subject, all.sites.methods$Tool_ID)))
           overlapTool_allSubject <- occ_Tool(all.sites.methods, tableM)
           list_overlap$All <- overlapTool_allSubject
         },
         "Gene"={
           Subject_ID <- unique(all.sites.methods$Subject_ID)
           #create a list where each element is the matrix tool x tool obtained for each subject
           list_overlap <- vector('list', length(Subject_ID))
           list_overlap_CS <- vector('list', length(Subject_ID))
           all.sites.methods$Tool_ID <- as.factor(all.sites.methods$Tool_ID)
           for(k in 1:length(Subject_ID)){
             #extract data of k-th subject
             temp <- all.sites.methods[which(all.sites.methods$Subject_ID==Subject_ID[k]),]
             #Calculate table siteID x tool, 1 the gene is called by tool, otherwise 0
             tableM <- as.data.frame.ts(sign(table(temp$Gene, temp$Tool_ID)))
             overlapTool <- occ_Tool(temp, tableM)
             overlapTool_CS <- overlapTool
             overlapTool_CS[upper.tri(overlapTool_CS)] <- t(overlapTool)[upper.tri(overlapTool)]
             list_overlap[[k]] <- overlapTool
             list_overlap_CS[[k]] <- overlapTool_CS
           }

           names(list_overlap) <- c(Subject_ID)
           names(list_overlap_CS)<- c(Subject_ID)
           ##ALL
           tableM <- as.data.frame.ts(sign(table(all.sites.methods$Gene, all.sites.methods$Tool_ID)))
           overlapTool_allSubject <- occ_Tool(all.sites.methods, tableM)

           list_overlap$All <- overlapTool_allSubject
         }, {stop(sprintf(paste("Wrong type: ", type, ", please use: Site or Gene.")))
         }
  )

  #CS SCORE
  calc_ov_ratio <- function(x_sites){
    out <- x_sites / diag(x_sites)
    out[is.na(out)] <-0
    diag(out) <- 0
    out <- sum(out) / (ncol(x_sites) * (ncol(x_sites) - 1))
  }
  CS <-sort(unlist(lapply(list_overlap_CS, calc_ov_ratio)))
  list_overlap$CS <- CS

  return(list_overlap)
}
