#' Integrate mutation evidence from TCGA
#'
#' @param temp_SNP data.frame produced by pre_process or get_TCGA_sites or site_annotation functions
#' @param genome the genome used for annotation (hg38/hg19)
#' @param project TCGA project ID
#' @param pipeline it is required for hg38 genome
#' @param file_type file name reported in tcga biolinks project. Only for hg19 genome
#' @param gene_info if it is TRUE the gene info will be reported, it required the entrez_gene_id annotation
#' @param filename output image filename
#' @param exclude_hypermutated if TRUE hypermutated subjects are excluded
#' @param ... Arguments passed to jpeg function
#' @return data.frame with mutation sites integrated with TCGA information
#' @import TCGAbiolinks
#' @import org.Hs.eg.db
#' @importFrom grDevices dev.off heat.colors jpeg
#' @importFrom stats na.omit
#' @export


integrate_TCGA <- function (temp_SNP, genome, project, pipeline = NULL,
                            file_type = NULL, gene_info = FALSE, filename = NULL, exclude_hypermutated=TRUE, ...)
{

  if (gene_info == TRUE & !"Gene" %in% colnames(temp_SNP)) {
    stop("The sites are not annotated! You should use: \"gene_info==FALSE\"")
  }
  #Switch to genome used
  switch(genome, hg38 = {
    if (is.null(pipeline)) {
      stop("You have to define pipelines argument.")
    } else {
      tcga <- GDCquery_Maf(project, pipelines = pipeline)
      #Extract column
      tcga <- tcga[, c("Entrez_Gene_Id", "Chromosome",
                       "Start_Position", "Reference_Allele", "Tumor_Seq_Allele2",
                       "Tumor_Sample_Barcode")]
      names(tcga) <- c("Gene", "CHROM", "POS", "REF", "ALT",
                       "Subject_ID")

      #Add column of Site_ID to data.frame with sites
      if(exclude_hypermutated==TRUE){
        tab_subj <- table(tcga$Subject_ID)
        quant_sub = quantile(tab_subj,type=7)
        Q1 = quant_sub[2]
        Q3 = quant_sub[4]
        IQR = Q3-Q1
        out_up = Q3+1.5*IQR
        sub_out <- tab_subj[tab_subj>out_up]
        if(length(sub_out)>0){
        sub_out <- names(sub_out)
        tcga <- tcga[-(which(tcga$Subject_ID %in% sub_out)),]
        }
      }
      tcga_site <- unique(tcga[, c("CHROM", "POS", "REF","ALT")])
      tcga_site$Site_TCGA <- rep(1, nrow(tcga_site))
      #Add column with 1 if sites reported in TCGA data
      temp_SNP <- merge(temp_SNP, tcga_site, by = c("CHROM", "POS", "REF"), sort = FALSE, all.x = T, suffixes = c("", "_TCGA"))
      temp_SNP$Site_TCGA <- ifelse(is.na(temp_SNP$Site_TCGA), 0, 1)
      n_plot=1
      #Add information about gene
      if (gene_info == TRUE) {
        n_plot=2
        tcga_gene <- unique(tcga[, c("Gene", "Subject_ID")])
        tcga_gene <- tcga_gene[tcga_gene$Gene>0,]
        Subject_ID <- unique(tcga_gene$Subject_ID)
        temp <- table(tcga_gene$Gene, tcga_gene$Subject_ID)
        binaryMatrix <- sign(temp)
        geneFreq <- t(apply(binaryMatrix, 1, function(x) mean(x)))
        geneFreq <- t(geneFreq)
        colnames(geneFreq) <- "Gene_mut_freq"
        geneDF <- data.frame(Gene = rownames(geneFreq), Gene_TCGA = rep(1, nrow(geneFreq)), Gene_mut_freq = geneFreq)
        rownames(geneDF) <- NULL
        #Add gene mutation frequency if gene reported in TCGA data
        temp_SNP <- merge(temp_SNP, geneDF, by = "Gene",
                          all.x = T)
        temp_SNP$Gene_TCGA <- ifelse(is.na(temp_SNP$Gene_TCGA), 0, 1)
      }
    }
  }, hg19 = {
    if (is.null(file_type)) {
      stop("You have to define file.type argument.")
    } else {
      tcga <- GDCquery(project, data.category = "Simple nucleotide variation",
                       data.type = "Simple somatic mutation", access = "open",
                       file.type = file_type, legacy = TRUE)
      GDCdownload(tcga)
      tcga <- GDCprepare(tcga)
      #Extract column
      tcga <- tcga[, c("Hugo_Symbol", "Chromosome", "Start_Position",
                       "Reference_Allele", "Tumor_Seq_Allele2", "Tumor_Sample_Barcode")]
      names(tcga) <- c("symbol", "CHROM", "POS", "REF",
                       "ALT", "Subject_ID")

      if(exclude_hypermutated==TRUE){
        tab_subj <- table(tcga$Subject_ID)
        quant_sub = quantile(tab_subj,type=7)
        Q1 = quant_sub[2]
        Q3 = quant_sub[4]
        IQR = Q3-Q1
        out_up = Q3+1.5*IQR
        sub_out <- tab_subj[tab_subj>out_up]
        if(length(sub_out)>0){
          sub_out <- names(sub_out)
          tcga <- tcga[-(which(tcga$Subject_ID %in% sub_out)),]
        }
      }
      tcga_site <- unique(tcga[, c("CHROM", "POS", "REF", "ALT")])
      tcga_site$Site_TCGA <- rep(1, nrow(tcga_site))
      temp_SNP$CHROM <- gsub("chr", "", temp_SNP$CHROM)
      #Add column with 1 if sites reported in TCGA data
      temp_SNP <- merge(temp_SNP, tcga_site, by = c("CHROM", "POS", "REF"), sort = FALSE, all.x = T, suffixes = c("", "_TCGA"))
      temp_SNP$CHROM <- paste0("chr", temp_SNP$CHROM)
      temp_SNP$Site_TCGA <- ifelse(is.na(temp_SNP$Site_TCGA), 0, 1)
      n_plot=1
      #Add information about gene
      if (gene_info == TRUE) {
        #map genes_symbol to entrez_id
        n_plot=2
        tcga_gene <- unique(tcga[, c("symbol", "Subject_ID")])
        e2s <- as.data.frame(org.Hs.egSYMBOL)
        tcga_gene <- merge(tcga_gene, e2s, by = c("symbol"), sort = FALSE, all.x = T)
        temp <- table(tcga_gene$gene_id, tcga_gene$Subject_ID)
        binaryMatrix <- sign(temp)
        geneFreq <- t(apply(binaryMatrix, 1, function(x) mean(x)))
        geneFreq <- t(geneFreq)
        colnames(geneFreq) <- "Gene_mut_freq"
        geneDF <- data.frame(Gene = rownames(geneFreq), Gene_TCGA = rep(1, nrow(geneFreq)), Gene_mut_freq = geneFreq)
        rownames(geneDF) <- NULL
        #Add gene mutation frequency if gene reported in TCGA data
        temp_SNP <- merge(temp_SNP, geneDF, by = "Gene", all.x = T)
        temp_SNP$Gene_TCGA <- ifelse(is.na(temp_SNP$Gene_TCGA), 0, 1)

      }
    }
  })

  if(!is.null(filename)){
    jpeg(filename,...)
    par(mfrow=c(1,n_plot))
    temp_SNP_plot <- consensus_Tools(temp_SNP)
    temp_SNP_plot <- temp_SNP_plot[!duplicated(temp_SNP_plot [,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject')]), ]
    barplot(table(temp_SNP_plot[temp_SNP_plot$Site_TCGA==1, "n_Tools"]), ylab="#Sites")
    if(gene_info == TRUE){
      barplot(table(temp_SNP_plot[temp_SNP_plot$Gene_TCGA==1, "n_Tools"]), ylab="#Genes")}
  }

  return(temp_SNP)
}
