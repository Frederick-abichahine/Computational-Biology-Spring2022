#' Perform site-level analyses
#'
#' @param sites data.frame produced by pre_process or get_TCGA_sites functions
#' @param directory output directory
#' @param cores number of cores to use
#' @importFrom gplots venn
#' @importFrom stringr str_split_fixed
#' @importFrom grDevices dev.off jpeg rainbow
#' @importFrom graphics plot barplot grid layout layout.show legend plot.new points
#' @importFrom stats na.omit dist hclust
#' @importFrom RColorBrewer brewer.pal
#' @export
#'
site_analysis <- function(sites, directory = NULL, cores = NULL){

  if(nrow(sites)==0){
    stop("Empty input")
  }
  if(is.null(directory)){
    stop("You have to define the output directory")
  }

  if(!dir.exists(directory)){
    dir.create(directory)
  }

  if("Gene" %in% colnames(sites)){
    sites <- sites[!duplicated(sites[,c('CHROM', 'POS', 'REF', 'ALT', 'SiteID_Subject', 'Tool_ID')]), ]
  }

  sites  <- consensus_Tools(sites, filename = NULL)
  listOutput <- get_sites_statistics(sites, type = "Site", filename = NULL)

  ##1
  sample_MS <- split(listOutput$var_per_subject[listOutput$var_per_subject$Type=="All", c("Tool_ID", "Sites")], listOutput$var_per_subject$Subject_ID[listOutput$var_per_subject$Type=="All"])
  for(i in 1:length(sample_MS)){
    rownames(sample_MS[[i]]) <- sample_MS[[i]]$Tool_ID
    sample_MS[[i]]$Tool_ID <- NULL
    colnames(sample_MS[[i]]) <- names(sample_MS)[i]
  }
  sample_MS <- Reduce(cbind, sample_MS)
  sample_MS <- sample_MS[, order(-colSums(sample_MS))]

  ##2
  sample_consensusTool<- table(listOutput$tool_per_var$n_Tools, listOutput$tool_per_var$Subject_ID)
  sample_consensusTool <- t(sample_consensusTool)/colSums(sample_consensusTool)
  ##3

  #Site co-occurrence
  ###plot 3
  ov_tool <- overlap_Tools(sites, type = "Site")
  CS <- ov_tool$CS
  if(is.null(cores)){
  ov_sub <- overlap_Subjects(sites, type = "Site")
  } else {
  ov_sub <- overlap_Subjects(sites, type = "Site", cores = cores)
  }

  ov_sub_all <- ov_sub$All
  n_site_all_sub <-  diag(ov_sub_all)


  X <-sample_consensusTool
  hc_row <- hclust(dist(X))
  X <- X[hc_row$order, ]
  sample_MS <- t(t(sample_MS)/colSums(sample_MS))
  sample_MS <- sample_MS[,match(rownames(X), colnames(sample_MS))]
  ###outlier proportion
  temp <- apply(sample_MS,1, function(x) quantile(x, type=7))
  samples_MS_new <- matrix(0, nrow = dim(sample_MS)[1], ncol = dim(sample_MS)[2])
  rownames(samples_MS_new) <- rownames(sample_MS)
  colnames(samples_MS_new) <- colnames(sample_MS)
  for(i in 1:dim(sample_MS)[1]){
    samples_MS_new[i,] <- ifelse(sample_MS[i,]>(temp[4,i]+1.5*(temp[4,i]-temp[2,i])),1,ifelse(sample_MS[i,]<(temp[2,i]-1.5*(temp[4,i]-temp[2,i])),-1,0))
  }
  samples_MS_new <-  samples_MS_new[,match(rownames(X), colnames(samples_MS_new))]
  CS <- CS[match(rownames(X), names(CS))]
  n_site_all_sub <- n_site_all_sub[match(rownames(X), names(n_site_all_sub))]
  n_tools <- nrow(sample_MS)
  if(n_tools<=9){
    col_P1 <- brewer.pal(n = 9, "Set1")[1:n_tools]
  } else{
    col_P1 <- rainbow(n_tools)
  }

  if(ncol(X)<=12){
    col_P2 <- brewer.pal(n = 12, "Set3")[1:ncol(X)]
  } else{
    col_P2 <- rainbow(ncol(X))
  }


  ###outlier subjects #sites
  quant_sub = quantile(n_site_all_sub,type=7)
  Q1 = quant_sub[2]
  Q3 = quant_sub[4]
  IQR = Q3-Q1
  out_up = Q3+1.5*IQR
  n_site_df <- as.data.frame(n_site_all_sub)
  n_site_df$outlier <- ifelse(n_site_df$n_site_all_sub>out_up,1,0)
  n_site_df$n <- seq(1:dim(n_site_df)[1])
  out_n_site <- n_site_df[n_site_df$outlier==1,]
  if(dim(out_n_site)[1]>=1){
    flag_p1 =1
  } else {
    flag_p1 =2
  }
  ###outlier consensus
  ind_1 <- which(colnames(X)=="1", arr.ind = T)
  if(length(ind_1)!=0){
    quant_sub = quantile(X[,ind_1], type=7)
    Q1 = quant_sub[2]
    Q3 = quant_sub[4]
    IQR = Q3-Q1
    out_cons = Q3+1.5*IQR
    X_df <- as.data.frame.ts(X)
    X_df$outlier <- ifelse(X_df[,ind_1]>= out_cons, 1, 0)
    X_df$n <- seq(1:dim(X_df)[1])
    out_X_df<- X_df[X_df$outlier==1,]
    if(dim(out_X_df)[1]>=1){
      flag_p2 =1
    } else {
      flag_p2 =2
    }

  }


  ###outlier subjects score
  quant_sub = quantile(CS,type=7)
  Q1 = quant_sub[2]
  Q3 = quant_sub[4]
  IQR = Q3-Q1
  out_up = Q1-1.5*IQR
  CS_df <- as.data.frame(CS)
  CS_df$outlier <- ifelse(CS_df$CS<out_up,1,0)
  CS_df$n <- seq(1:dim(CS_df)[1])
  out_CS <- CS_df[CS_df$outlier==1,]
  if(dim(out_CS)[1]>=1){
    flag_p3 =1
  } else {
    flag_p3 =2
  }
  n_subj <- length(CS)
  ###plot 1
  jpeg(paste0(directory,"/detailed_consensus_plot_sites.jpeg"), width = 180, height = 180, units = "mm", res = 300)
  layout.show(layout(matrix(c(1,2,3,4,5,6,7,8), nrow=4, byrow = T), heights = c(0.2, 0.2, 0.4, 0.2), widths = c(0.85,0.15)))
  par(mar = c(0.5,4,1,0))
  par(oma = c(4,0,0,1))

  #barplot(n_site_all_sub,ylab = "# Sites", las=2,cex.axis = 0.7, cex.names = 1,space = 0, xaxt="n", col="lemonchiffon")
  barplot(n_site_all_sub,ylab = "# Sites", las=2,cex.axis = 0.7, cex.names = 1,space = 0, xaxt="n", col="lemonchiffon", ylim=c(0,max(n_site_all_sub+(n_site_all_sub)/5)))
  if(flag_p1==1){
  n_site_df$n <- seq(1:dim(n_site_df)[1])
  out_n_site <- n_site_df[n_site_df$outlier==1,]
  points(x=out_n_site$n-n_subj/100, y=out_n_site$n_site_all_sub+(out_n_site$n_site_all_sub)/10, pch="*", cex=2, col="black")
  }
  plot.new()
  ##2
  par(mar = c(0.5,4,2,0))
  barplot(as.matrix(sample_MS), las = 2, ylab = "% Sites", cex.axis = 0.7, cex.names = 1,space = 0, xaxt="n", col=col_P1)
  ind_out <- which(colSums(abs(samples_MS_new))>=1)
  if(length(ind_out)>=1){
    for(i_out in 1:length(ind_out)){
      ind_out2 <- which(samples_MS_new[,ind_out[i_out]]!=0)
      for(j_out in 1:length(ind_out2)){
        points(x = ind_out[i_out]-dim(samples_MS_new)[2]/100, y=1+0.05*j_out, col= col_P1[ind_out2[j_out]], pch="*", xpd=T, cex=2)
      }
    }
  }
  par(mar = c(0.5,1,0,0))
  plot.new()
  legend("left", legend = rownames(sample_MS), pch = 15, col = col_P1, title = "", cex = 1, bty = "n")
  ##3
  par(mar = c(0.5,4,1.5,0))
  barplot(t(X), las = 2, ylab = "% Sites",cex=1, cex.axis =0.7, cex.names = 1, space = 0, xaxt="n", col=col_P2 )
  if(flag_p2==1){
    points(x=out_X_df$n-n_subj/100, y=rep(1+0.03,dim(out_X_df)[1]), pch="*", cex=2, col=col_P2[which(colnames(X)=="1")], xpd=T)
  }
  par(mar = c(0.5,1,0,0.5))
  plot.new()
  legend("center", legend = colnames(X), pch=15, col =  col_P2, title = "Consensus\neach subject", cex = 0.9, bty = "n")
  ##4
  par(mar = c(2,4,0,0))
  #barplot(CS , las = 2, ylab = "s",space = 0, ylim = c(max(CS),0), cex.axis = 0.7, col="moccasin")
  barplot(CS , las = 2, ylab = "CS",space = 0, ylim = c(max(CS)+0.2,0), cex.axis = 0.7, col="moccasin")
  if(flag_p3==1){
  points(x=out_CS$n-n_subj/100, y=rep(max(CS)+0.05,dim(out_CS)[1]), pch="*", cex=2, col="black")
  }
  dev.off()



  prop_tool <- data.frame(subj = colnames(samples_MS_new), Imbalance_in_site_number_across_tools= colSums(abs(samples_MS_new)), stringsAsFactors = F)
  prop_cons <- data.frame(subj = rownames(X), Imbalance_in_consensus_among_tools= X_df$outlier, stringsAsFactors = F)
  CS_df_2 <- data.frame(subj= rownames(CS_df), CS = CS_df$outlier, stringsAsFactors = F)
  n_site_df_2 <- data.frame(subj= rownames(n_site_df), hypermutated = n_site_df$outlier, stringsAsFactors = F)
  df_outlier <- merge(n_site_df_2, prop_tool, by="subj")
  df_outlier <- merge(df_outlier, prop_cons, by = "subj")
  df_outlier <- merge(df_outlier, CS_df_2, by="subj")

  write.table(df_outlier, file = paste0(directory,"/subj_outliers_sites.txt"),  row.names = F, sep = "\t")
  write.table(samples_MS_new, file = paste0(directory,"/tool_outliers_subj_sites.txt"),col.names = NA, sep = "\t")


  #Table Site_ID_Subject_ID, Site_ID, Subject_ID, number of Tools supporting the site
  write.table(listOutput$tool_per_var, file=paste0(directory,"/site_subj_n_Tools.txt"), row.names = F, sep="\t")

  #Table Subject_ID, consensus, number of sites
  new_df <- data.frame(rownames(X))
  new_df2 <- cbind(X, n_site_all_sub, CS)
  new_df <- cbind(new_df, new_df2)
  d_nf <- dim(new_df)[2]
  colnames(new_df)[c(1,d_nf-1,d_nf)] <- c("Subject_ID","n_Sites", "s")
  write.table(new_df, file = paste0(directory,"/subj_consensus_Sites_s.txt"),  row.names = F, sep = "\t")

  #barplot: consensus across tools in each tool
  tab <- table(listOutput$consensus_tool$n_Tools, listOutput$consensus_tool$Tool_ID)
  consensusTool <- t(tab)/colSums(tab)
  if(nrow(tab)<=12){
    col_P3 <- brewer.pal(n = 12, "Set3")[1:nrow(tab)]
  } else{
    col_P3 <- rainbow(max(15,nrow(tab)))[1:nrow(tab)]
  }
  ###plot 2
  jpeg(paste0(directory,"/Global_consensus_plot_sites.jpeg"), width = 90, height = 90, units = "mm", res=300)
  layout.show(layout(matrix(c(1,2,3,4), nrow=2, byrow = T), heights = c(0.3,0.7), widths =c(0.8, 0.2)))
  par(mar = c(0.5,4,2,0))
  n_sites <- table(sites$Tool_ID)
  barplot(n_sites, las=2, ylab="#Sites",space = 0.2, xaxt="n", cex.axis = 0.7, col="moccasin")
  plot.new()
  consensusTool <- consensusTool[match(names(n_sites),rownames(consensusTool)),]
  par(mar = c(7,4,0.2,0))
  barplot(t(consensusTool),las=2, ylab="% Sites", cex.axis = 0.7, col=col_P3)
  par(mar = c(6,0.5,0.2,0.5))
  plot.new()
  legend("center", legend = colnames(consensusTool), pch=15, col = col_P3, title="Consensus\n(All Subjects)",cex=0.6,bty="n")

  dev.off()

  #Table tool_id, consensus among tools, total number of sites
  new_df <- data.frame(names(n_sites), stringsAsFactors = F)
  new_df2 <-  cbind( consensusTool, n_sites)
  new_df <- cbind(new_df, new_df2)
  d_nf <- dim(new_df)[2]
  colnames(new_df)[c(1,d_nf)] <- c("Tool_ID","n_Sites")
  write.table(new_df, file=paste0(directory,"/tool_consensus_Sites.txt"),  row.names = F, sep="\t")

  ##Clustering
  ov_sub_cl <- clustering_matrix(ov_sub$All)
  ov_sub_cl_CV <- ov_sub$cv
  ov_sub_cl_CV <- ov_sub_cl_CV[match(rownames(ov_sub_cl), rownames(ov_sub_cl_CV)),match(rownames(ov_sub_cl), colnames(ov_sub_cl_CV))]

  jpeg(paste0(directory,"/Co-occurrence_plots_sites.jpeg"), width = 180, height = 90, units = "mm", res=300)
  par(mfrow=c(1,2))
  plot_matrix_tool(ov_tool$All)
  plot_matrix_subj(ov_sub_cl, ov_sub_cl_CV)
  dev.off()

  #Site co-occurrence tool-by-tool
  write.table(ov_tool$All, file=paste0(directory,"/Tool_by_tool_sites_matrix.txt"), col.names = NA, sep="\t")

  #Site co-occurrence subj-by-subj in each tool and together
  dim_ov_sub <- length(ov_sub)
  ov_sub_temp <- ov_sub[c(1:(dim_ov_sub-4), dim_ov_sub)]
  for(i in 1:length(ov_sub_temp)){
    write.table(ov_sub_temp[[i]], file=paste0(directory,"/Subj_by_subj_",names(ov_sub_temp)[i],"_sites_matrix.txt"),  col.names = NA,sep="\t")
  }
}
