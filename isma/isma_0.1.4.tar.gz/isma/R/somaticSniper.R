#' Read vcf of SomaticSniper and standardized file into a unique matrix.
#'
#' @param fileToolList List of files separated by tools
#' @param fileList  list with all files and informations
#' @param i Index of fileToolList
#' @param k Index of the iteration
#' @param all_sites Empty list in which will be save the mutation sites
#' @param nucl nucleotide

somaticSniper <- function(fileToolList, fileList, i, k, all_sites, nucl){

  for (j in 1:length(fileToolList[[i]])){

    file <- read_VCF(fileToolList, fileList, i, j)
    indSS <- which(unlist(strsplit(file[1,"FORMAT"],":"))=="SS")
    file_pass <- file[which(apply(file, 1 ,function(x) unlist(strsplit(x["TUMOR"],":"))[indSS])==2), ]
    #ind Occurrence count for each base at this site (A,C,G,T)"
    indBCOUNT <- which(unlist(strsplit(file_pass[1,"FORMAT"],":"))=="BCOUNT")
    file_pass$REF <- toupper(file_pass$REF)
    file_temp1<- file_pass[grep(",", file_pass$ALT), ]
    file_pass <- file_pass[which(file_pass$REF %in% nucl),]
    site_temp <- data.frame()
    if (dim(file_temp1)[1]>0){
      file_pass<- file_pass[-grep(",", file_pass$ALT), ]
      for (t in 1:dim(file_temp1)[1]){
        tempALT <- unlist(strsplit(file_temp1$ALT[t], ","))
        indRef <- grep(file_temp1$REF[t], nucl)
        tempTref <- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$TUMOR[t], ":"))[indBCOUNT], ",")))[indRef]
        tempCref <- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$NORMAL[t], ":"))[indBCOUNT], ",")))[indRef]
        #tempINFO <- ifelse(unlist(strsplit(file_temp1[t,8],":"))[12]=="2", 2, 1)
        for(f in 1:length(tempALT)){
          indAlt <- grep(tempALT[f], nucl)
          tempTalt <- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$TUMOR[t],":"))[indBCOUNT], ",")))[indAlt]
          tempCalt <- as.numeric(unlist(strsplit(unlist(strsplit(file_temp1$NORMAL[t],":"))[indBCOUNT], ",")))[indAlt]

          site_temp <- rbind(site_temp, data.frame(
            file_temp1[t,c("CHROM","POS","REF")],
            ALT = tempALT[f],
            Design = fileList$Design[fileToolList[[i]][j]==fileList$File],
            #INFO = tempINFO,
            Tumor_ref_reads = tempTref,
            Tumor_var_reads = tempTalt,
            Normal_ref_reads = tempCref,
            Normal_var_reads = tempCalt,
            Subject_ID = fileList$Subject_ID[fileToolList[[i]][j]==fileList$File],
            Variant_Type = ifelse((sapply(file_temp1$REF[t], function(x) length(unlist(strsplit(x, "")))) + sapply(tempALT[f], function(x) length(unlist(strsplit(x, ""))))==2),"SNP","INDEL"),
            Tool_ID = names(fileToolList)[i],
            stringsAsFactors = FALSE)
          )
          site_temp[is.na(site_temp)] <-0
        }
      }
    }

    indRef <- apply(file_pass, 1, function(x) grep(x["REF"], nucl))
    indAlt <- apply(file_pass, 1, function(x) grep(x["ALT"], nucl))
    tempT <- apply(file_pass, 1,function(x) as.numeric(unlist(strsplit(unlist(strsplit(x["TUMOR"],":"))[indBCOUNT], ","))))
    tempC <- apply(file_pass, 1,function(x) as.numeric(unlist(strsplit(unlist(strsplit(x["NORMAL"],":"))[indBCOUNT], ","))))
    #tempINFO <- apply(file_pass, 1, function(x) ifelse(unlist(strsplit(x[8], ":"))[12]=="2", 2, 1))

    tempTref <- rep(0, dim(file_pass)[1])
    tempCref <- rep(0, dim(file_pass)[1])
    tempTalt <- rep(0, dim(file_pass)[1])
    tempCalt <- rep(0, dim(file_pass)[1])

    for(t in 1:dim(file_pass)[1]){
      tempTref[t] <- tempT[indRef[t], t]
      tempCref[t] <- tempC[indRef[t], t]
      tempTalt[t] <- tempT[indAlt[t], t]
      tempCalt[t] <- tempC[indAlt[t], t]
    }

    file_pass <- data.frame(
      file_pass[ ,c("CHROM","POS","REF","ALT")],
      Design = fileList$Design[fileToolList[[i]][j]==fileList$File],
      #INFO = tempINFO,
      Tumor_ref_reads = tempTref,Tumor_var_reads=tempTalt,
      Normal_ref_reads = tempCref,
      Normal_var_reads = tempCalt,
      Subject_ID = fileList$Subject_ID[fileToolList[[i]][j]==fileList$File],
      Variant_Type = ifelse((sapply(file_pass$REF, function(x) length(unlist(strsplit(x, "")))) + sapply(file_pass$ALT, function(x) length(unlist(strsplit(x, ""))))==2), "SNP", "INDEL"),
      Tool_ID = names(fileToolList)[i],
      stringsAsFactors = FALSE)

    file_pass <- rbind(file_pass, site_temp)
    all_sites[[k]] <- file_pass
    k=k+1
  }
  newL <- list(all_sites = all_sites,ind = k)
  return(newL)
}
