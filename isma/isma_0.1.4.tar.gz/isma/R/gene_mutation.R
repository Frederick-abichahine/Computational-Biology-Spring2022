#' Calculates the gene-by-subject mutation matrix and the gene mutation frequency vectors.
#'
#' @param all.sites.methods data.frame with annotated mutation sites
#' @param Tool_ID vector of Tool_IDs to take into account
#' @param filename string with path, file name, and format for saving a plot of gene mutation frequency considering all tools and standard deviation
#' @param ... Arguments to be passed to methods, such as graphical parameters
#'
#' @return a list with:
#' \itemize{
#' \item{data.frame with the number mutation sites in each (genes and Subjects) pair;}
#' \item{data.frame with gene mutation frequency}
#' }
#' @importFrom grDevices dev.off jpeg
#' @importFrom graphics plot
#' @export

gene_mutation <- function(all.sites.methods, Tool_ID = NULL, filename=NULL, ...) {


  #if Tool_IDs are not specified all tools are used
  if(is.null(Tool_ID)){
    Tool_ID <- unique(all.sites.methods$Tool_ID)
  }else if(!is.null(Tool_ID)){
    Tool_ID_uniq <- unique(all.sites.methods$Tool_ID)
    temp <- setdiff(Tool_ID, Tool_ID_uniq)
    if(length(temp)>0){
      stop(sprintf(paste("Wrong Tool_ID: ", temp, ".")))
    }
  }

  all.sites.methods$Design <- as.factor(all.sites.methods$Design)
  design_vect <- unique(all.sites.methods$Design)

  #define a list where each element is the table gene x subject_ID obtained for each tool_ID
  # the table reports the number of mutated sites in each gene and subject_ID
  list_mutated_nSite_Gene <- vector('list', length(Tool_ID))

  #define a list where each element is the gene mutation frequency for each tool_ID
  list_gene_mutation_freq <- vector('list', length(Tool_ID))

  for(k in 1:length(Tool_ID)){
    #extract sites of k-th tool
    temp <- all.sites.methods[which(all.sites.methods$Tool_ID %in% Tool_ID[k]), ]
    uniqueSiteID_Subject <- temp[!duplicated(temp[,c("SiteID_Subject","Gene")]), ]

    #Amount of mutation sites for each gene
    list_mutated_nSite_Gene[[k]] <- t(table(uniqueSiteID_Subject$Subject_ID, uniqueSiteID_Subject$Gene))
    binaryMatrix <- sign(list_mutated_nSite_Gene[[k]])
    uniqueSubjectID_EXP <- unique(uniqueSiteID_Subject[,c("Subject_ID", "Design")])

    #extract the design for each subject ording the matrix according to the colnames of binaryMatrix
    design <- uniqueSubjectID_EXP[match(colnames(binaryMatrix), uniqueSubjectID_EXP$Subject_ID), "Design"]

    #Calculate the gene mutation frequency using the design column:
    #>1 design -> matrix with #of column equal to #of design order by design_vect
    #1 design -> matrix with 1 column, if/else because if I use
    #"t(apply(binaryMatrix, 1, function(x) tapply(x, design, mean))) I need to transpose the matrix again
    if(length(design_vect)>1){
      geneFreq <- t(apply(binaryMatrix, 1, function(x) tapply(x, design, mean)))
      geneFreq <- geneFreq[,match(design_vect,colnames(geneFreq))]
      geneFreq[is.na(geneFreq)] <- 0
    } else if(length(design_vect) ==1){
      geneFreq <- t(apply(binaryMatrix, 1, function(x) mean(x)))
      geneFreq <- t(geneFreq)
      colnames(geneFreq) <- levels(design_vect)
    }
    list_gene_mutation_freq[[k]] <- geneFreq
    colnames(list_gene_mutation_freq[[k]]) <- paste0(colnames(list_gene_mutation_freq[[k]]),"_f_",Tool_ID[k])
  }
  names(list_gene_mutation_freq) <- Tool_ID
  names(list_mutated_nSite_Gene) <- Tool_ID

  #Calculate standard deviation of gene mutation frequency across tool results
  list_sd_temp <- vector("list",length(design_vect))
  #calculate sd for each design separately
  for(des_ind in 1:length(design_vect)){
    #create for each tool a df with gene and its mutation frequency
    df <- lapply(list_gene_mutation_freq, function(x) data.frame(gene=rownames(x), x[,des_ind], stringsAsFactors = F))
    #rename the column of gene mutation frquency with the names of tools in order to not have warnings during merge operation
    for(n_tool in 1:length(df)){
      colnames(df[[n_tool]]) <- c("gene", names(df)[[n_tool]])
    }
    #create a dataframe with gene and mutation frequency obtained for each mutation caller
    uniq_df <- Reduce(function(x, y) merge(x, y, all=TRUE, by="gene"), df)
    uniq_df[is.na(uniq_df)] <-0
    #calculate standard deviation excluding gene colum
    list_sd_temp[[des_ind]] <- data.frame(gene = uniq_df$gene, sd = apply(uniq_df[,-1],1,sd), stringsAsFactors = F)
    #rename column using the design
    colnames(list_sd_temp[[des_ind]]) <- c("gene", paste0(design_vect[des_ind],"_sd"))
  }
  names(list_sd_temp) <- design_vect
  #create a dataframe with all design results
  uniq_df <- Reduce(function(x, y) merge(x, y, all=TRUE, by="gene"), list_sd_temp)
  uniq_df[is.na(uniq_df)] <- 0
  list_gene_mutation_freq$sd_freq <- uniq_df

  ###ALL
  temp <- all.sites.methods[which(all.sites.methods$Tool_ID %in% Tool_ID), ]
  uniqueSiteID_Subject <- temp[!duplicated(temp[,c("SiteID_Subject","Gene")]), ]
  #Amount of mutation sites for each gene
  mutateSite_Gene <- t(table(uniqueSiteID_Subject$Subject_ID, uniqueSiteID_Subject$Gene))
  list_mutated_nSite_Gene$All <- mutateSite_Gene
  binaryMatrix <- sign(mutateSite_Gene)
  uniqueSubjectID_EXP <- unique(uniqueSiteID_Subject[,c("Subject_ID", "Design")])

  design <-  uniqueSubjectID_EXP[match(colnames(binaryMatrix), uniqueSubjectID_EXP$Subject_ID), "Design"]
  if(length(design_vect)>1){
    geneFreq <- t(apply(binaryMatrix, 1, function(x) tapply(x, design, mean)))
    geneFreq <- geneFreq[,match(design_vect,colnames(geneFreq))]
    geneFreq[is.na(geneFreq)] <- 0
  } else if(length(design_vect) ==1){
    geneFreq <- t(apply(binaryMatrix, 1, function(x) mean(x)))
    geneFreq <- t(geneFreq)
    colnames(geneFreq) <- levels(design_vect)
  }
  colnames(geneFreq) <- paste0(colnames(geneFreq),"_f_all")
  list_gene_mutation_freq$All <- geneFreq
  list_Gene_Mutation <- list(mutate_site_gene = list_mutated_nSite_Gene, gene_frequency=list_gene_mutation_freq)

  #plot sd vs gene mutation frequency for each design
  if(!is.null(filename)){
    jpeg(filename,...)
    par(mfrow=c(length(design_vect),1))
    sd_freq <-  list_Gene_Mutation$gene_frequency$sd_freq
    freq <- list_Gene_Mutation$gene_frequency$All
    sd_freq <- sd_freq[match(rownames(freq), sd_freq$gene),]
    for(des_v in 1: length(design_vect)){
      plot(freq[,des_v],  sd_freq[,des_v+1], xlab="Gene_Mut_Freq_All", ylab="stdev", main=design_vect[des_v])

    }
    dev.off()
  }
  return(list_Gene_Mutation)

}

