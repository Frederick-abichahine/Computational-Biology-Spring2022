#' Read vcf and re-name column of Tumor and Normal fields.
#'
#' @param fileToolList List of files separated by tools
#' @param fileList  list with all files and informations
#' @param i Index of fileToolList
#' @param j Index of file in fileToolList

read_VCF <- function(fileToolList, fileList, i, j){

  #Read vcf file with vcfR package
  tmp.vcf<-readLines(fileToolList[[i]][j])
  indCHROM <- grep("#CHROM",tmp.vcf)
  if(is.na(tmp.vcf[indCHROM+1])){
    file  <- as.data.frame(matrix(0, ncol = 11, nrow = 0))
    temp <- unlist(strsplit(tmp.vcf[length(tmp.vcf)],"\t"))
    colnames(file) <- temp
  } else{
    file<-read.table(fileToolList[[i]][j], stringsAsFactors = FALSE, colClasses =  c("character"))
    tmp.vcf<-tmp.vcf[-(grep("#CHROM",tmp.vcf)+1):-(length(tmp.vcf))]
    vcf.names<-unlist(strsplit(tmp.vcf[length(tmp.vcf)],"\t"))
    names(file)<-vcf.names
  }
  file <- file[, c(-3,-6)]
  #Rename the column of Tumor and Normal fields
  file <- file[ ,c(names(file)[1:7], fileList$Tumor_ID[fileToolList[[i]][j]==fileList$File],
                   fileList$Normal_ID[fileToolList[[i]][j]==fileList$File])]
  names(file)[1] <- "CHROM"
  names(file)[8] <- "TUMOR"
  names(file)[9] <- "NORMAL"
  return(file)
}
