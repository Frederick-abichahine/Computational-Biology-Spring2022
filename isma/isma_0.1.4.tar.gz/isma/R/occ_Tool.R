#' Calculate co-occurence and ratio - Tool
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param tableM table of site/gene and tool/subj
#' @return co-occuc matrix and ratio
#' @importFrom utils combn
#' @importFrom igraph get.adjacency
#' @importFrom igraph graph.data.frame
#' @importFrom stats dist hclust

occ_Tool <- function(all.sites.methods, tableM){

  uniqueTool_Subject <- unique(all.sites.methods$Tool_ID)
  #considere the combination of pairs tool-ith and tool-jth
  ijpairs <- t(combn(length(levels(uniqueTool_Subject)), 2))
  #if the the rowSum of tableM is bigger than 1 the site is reported in both tool i,j
  ijpairs <- cbind(ijpairs, overlap=apply(ijpairs, 1, function(x) sum(rowSums(tableM[, x])>1)))
  overlapTool_allSubject <- as.matrix(get.adjacency(graph.data.frame(ijpairs, directed = T), attr = "overlap"))
  overlapTool_allSubject <- apply(overlapTool_allSubject,2, function(x) as.numeric(x))
  diag(overlapTool_allSubject) <- colSums(tableM)
  overlapTool_allSubject[lower.tri(overlapTool_allSubject)] <- t(overlapTool_allSubject)[lower.tri(overlapTool_allSubject)]
  colnames(overlapTool_allSubject) <- colnames(tableM)
  rownames(overlapTool_allSubject) <- colnames(tableM)
  #calculate ratio
  ijpairs2 <- cbind(ijpairs, overlap=apply(ijpairs, 1, function(x) x[3]/(diag(overlapTool_allSubject)[x[1]]+diag(overlapTool_allSubject)[x[2]]-x[3])))
  overlapTool_allSubject2 <- as.matrix(get.adjacency(graph.data.frame(ijpairs2, directed = T), attr = "overlap"))
  overlapTool_allSubject2[lower.tri(overlapTool_allSubject2)] <- t(overlapTool_allSubject2)[lower.tri(overlapTool_allSubject2)]
  colnames(overlapTool_allSubject2) <- colnames(tableM)
  rownames(overlapTool_allSubject2) <- colnames(tableM)
  #clustering by co-occurence matrix
  overlapTool_allSubject <- clustering_matrix(overlapTool_allSubject)
  overlapTool_allSubject2 <- overlapTool_allSubject2[match(rownames( overlapTool_allSubject), rownames( overlapTool_allSubject2)),match(colnames( overlapTool_allSubject), colnames( overlapTool_allSubject2))]
  overlapTool_allSubject[lower.tri(overlapTool_allSubject)] <- t(overlapTool_allSubject2)[lower.tri(overlapTool_allSubject2)]
  overlapTool_allSubject <- round(overlapTool_allSubject,2)
  overlapTool_allSubject <- t(overlapTool_allSubject)
  return(overlapTool_allSubject)
}
