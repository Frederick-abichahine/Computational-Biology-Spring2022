#' Save all mutation sites as a VCF file
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param file_output string with directory and filename of the vcf
#'
#' @return vcf file with the colum CHROM, POS, ID, REF, ALT, QUAL, FILTER, INFO.
#' The ID field is the Site_ID reported in the integrated mutation sites data.frame
#' @export
#' @importFrom utils write.table

save_VCF_for_annotation <- function(all.sites.methods, file_output){

  #take unique sites
  all.sites.methods.uniq  <- unique(all.sites.methods[, c("CHROM", "POS", "REF", "ALT","Site_ID")])
  #Create VCF file
  temp <- data.frame(
    CHROM = all.sites.methods.uniq$CHROM,
    POS = all.sites.methods.uniq$POS,
    ID = all.sites.methods.uniq$Site_ID,
    REF = all.sites.methods.uniq$REF,
    ALT = all.sites.methods.uniq$ALT,
    QUAL = rep(".", nrow(all.sites.methods.uniq)),
    FILTER = rep("PASS", nrow(all.sites.methods.uniq)),
    INFO = rep(".", nrow(all.sites.methods.uniq))
  )

  write.table("##fileformat=VCFv4.0", file_output, sep = "\t", append = TRUE, row.names = FALSE, col.names = FALSE, quote = FALSE)
  colNam <- c("#CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER", "INFO")
  write.table(t(colNam), file_output, sep = "\t", append = TRUE, row.names = FALSE, col.names = FALSE, quote = FALSE)
  write.table(temp, file_output, sep = "\t", append = TRUE, row.names = FALSE, col.names = FALSE, quote = FALSE)
}
