#' Calculate co-occurence and ratio - Subject
#'
#' @param all.sites.methods data.frame with mutation sites
#' @param tableM table of site/gene and tool/subj
#' @param cores number of cores to use
#' @return co-occuc matrix and ratio
#' @importFrom utils combn
#' @importFrom igraph get.adjacency
#' @importFrom igraph graph.data.frame
#' @importFrom stats dist hclust
#' @import parallel

occ_Sub <- function(all.sites.methods, tableM, cores=NULL){

  uniqueSiteID_Subject <- all.sites.methods[!duplicated(all.sites.methods$SiteID_Subject), ]
  #considere the combination of pairs tool-ith and tool-jth
  ijpairs <- t(combn(length(levels(uniqueSiteID_Subject$Subject_ID)), 2))
  #if the the rowSum of tableM is bigger than 1 the site is reported in both subject i,j
  if(is.null(cores)){
    ijpairs <- cbind(ijpairs, overlap=apply(ijpairs, 1, function(x) sum(rowSums(tableM[, x])>1)))
  }else{
    ijpairs <- cbind(ijpairs, overlap=unlist(mclapply(1: nrow(ijpairs), function(x) sum(rowSums(tableM[, ijpairs[x,]])>1), mc.cores = cores, mc.allow.recursive = TRUE)))
  }
  overlapSubjects <- as.matrix(get.adjacency(graph.data.frame(ijpairs, directed = T), attr = "overlap"))
  #diagonal is the number of sites for each subject
  diag(overlapSubjects) <- colSums(tableM)
  overlapSubjects[lower.tri(overlapSubjects)] <- t(overlapSubjects)[lower.tri(overlapSubjects)]
  colnames(overlapSubjects) <- colnames(tableM)
  rownames(overlapSubjects) <- colnames(tableM)

  return(overlapSubjects)
}
