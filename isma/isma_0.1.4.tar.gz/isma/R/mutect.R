#' Read vcf of Mutect v1/v2 and standardized file into a unique matrix.
#'
#' @param fileToolList List of files separated by tools
#' @param fileList  list with all files and informations
#' @param i Index of fileToolList
#' @param k Index of the iteration
#' @param all_sites Empty list in which will be save the mutation sites


mutect <- function(fileToolList, fileList, i, k, all_sites){

  for (j in 1:length(fileToolList[[i]])){

    file <- read_VCF(fileToolList, fileList,i, j)
    file_pass <- file[file$FILTER=="PASS", ]
    indAD <- which(unlist(strsplit(file_pass[1,"FORMAT"],":"))=="AD")
    temp1C <- apply(file_pass, 1, function(x) as.numeric(unlist(strsplit(unlist(strsplit(x["TUMOR"], ":"))[indAD], ","))))
    #0:3,1:.:3:0.250
    #y <- gsub("$.+:([^:]+:", "\\1", x)
    temp2C <- apply(file_pass, 1, function(x) as.numeric(unlist(strsplit(unlist(strsplit(x["NORMAL"], ":"))[indAD], ","))))

    file_pass <- data.frame(
      file_pass[,c("CHROM","POS","REF","ALT")],
      Design = fileList$Design[fileToolList[[i]][j]==fileList$File],
      # INFO=as.numeric("2"),
      Tumor_ref_reads=temp1C[1,],
      Tumor_var_reads=temp1C[2,],
      Normal_ref_reads=temp2C[1,],
      Normal_var_reads=temp2C[2,],
      Subject_ID=fileList$Subject_ID[fileToolList[[i]][j]==fileList$File],
      Variant_Type= ifelse((sapply(file_pass$REF, function(x) length(unlist(strsplit(x, "")))) + sapply(file_pass$ALT, function(x) length(unlist(strsplit(x, ""))))==2),"SNP","INDEL"),
      Tool_ID=names(fileToolList)[i],
      stringsAsFactors = FALSE
    )
    all_sites[[k]] <- file_pass
    k=k+1}
  newL <- list(all_sites=all_sites,ind=k)
  return(newL)
}
