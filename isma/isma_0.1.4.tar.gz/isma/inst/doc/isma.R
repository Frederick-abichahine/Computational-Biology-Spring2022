## ---- eval=FALSE---------------------------------------------------------
#  install.packages(c("devtools", "gplots", "ggplot2", "igraph", "lattice", "knitr", "RColorBrewer", "rmarkdown", "stringr", "UpSetR", "vcfR"))

## ---- eval=FALSE---------------------------------------------------------
#  devtools::install_github(repo = "BioinformaticsFMRP/TCGAbiolinks")

## ---- eval=FALSE---------------------------------------------------------
#  if(!requireNamespace("BiocManager", quietly = TRUE))
#  install.packages("BiocManager")
#  BiocManager::install(c("IRanges", "GenomicRanges", "GenomicFeatures", "org.Hs.eg.db", "Rsamtools", "SummarizedExperiment", "TxDb.Hsapiens.UCSC.hg19.knownGene", "TxDb.Hsapiens.UCSC.hg38.knownGene", "VariantAnnotation"))

## ---- eval=FALSE---------------------------------------------------------
#  source("https://bioconductor.org/biocLite.R")
#  biocLite(c("IRanges", "GenomicRanges", "GenomicFeatures", "org.Hs.eg.db", "Rsamtools", "SummarizedExperiment", "TxDb.Hsapiens.UCSC.hg19.knownGene", "TxDb.Hsapiens.UCSC.hg38.knownGene", "VariantAnnotation"))

## ---- eval=FALSE---------------------------------------------------------
#  install.packages("/yourpath/isma_0.3.0.tar.gz", repos=NULL)
#  library(isma)

## ---- message=FALSE, warning=FALSE, eval=TRUE, echo=FALSE----------------
library(isma)
data(configuration_file)
print(configuration_file)

## ---- eval=F, message=FALSE, warning = FALSE-----------------------------
#  sites <- pre_process(configuration_file)
#  site_analysis(sites, directory = "/yourpath/output", cores = 2)
#  sites_ann <- site_annotation(sites, genome = "hg38")
#  gene_analysis(sites_ann, directory = "/yourpath/output", cores = 2)
#  ese1 <- ese_allsubj(sites, type = "Site")
#  ese2 <- ese_tool_subj(sites, type = "Site")
#  ese3 <- ese_subj_tool(sites, type = "Site")
#  sites_ann<- integrate_TCGA(sites_ann, genome = "hg38", project = "BRCA", pipeline = "mutect2", gene_info = TRUE)
#  

## ---- eval=F, message=FALSE, warning = FALSE-----------------------------
#  sites <- pre_process(configuration_file)

## ---- eval=F, message=FALSE, warning = FALSE-----------------------------
#  sites <- get_TCGA_sites(tools = c("muse", "mutect2", "varscan2","somaticsniper"), n_subjects = 50, seed_n = 2) #demo with TCGA data, use seed option to obtain each time the same subjects. NB. The barcode of subjects download are not the same of the selected 50 subjects.
#  data(barcode_50) #load the barcodes of the 50 selected subjects
#  sites <- get_TCGA_sites(tools = c("muse", "mutect2", "varscan2","somaticsniper"), barcode = barcode_50) #demo with TCGA data of the selected 50 subjects
#  data(sites) #precomputed results

## ---- eval=T, message=FALSE, warning = FALSE, echo=FALSE-----------------
data(sites)

## ---- eval=T, message=FALSE, warning = FALSE-----------------------------
head(sites)

## ---- eval=F, message=FALSE, warning = FALSE-----------------------------
#  site_analysis(sites, directory = "/yourpath/output", cores = 2)

## ---- fig.width=4, fig.height=4, echo=FALSE, results='hide',message=FALSE----
data("output_SA")
  m<-layout(matrix(c(1,2,3,4), nrow=2, byrow = T), heights = c(0.3,0.7), widths =c(0.8, 0.2))
  par(mar = c(0.5,4,2,0))
  barplot(output_SA$n_sites, las=2, ylab="#Sites",space = 0.2, xaxt="n", cex.axis = 0.7, col="moccasin")
  plot.new()

  par(mar = c(7,4,0.2,0))
  barplot(t(output_SA$consensusTool),las=2, ylab="% Sites", cex.axis = 0.7, col=output_SA$col_P3)
  par(mar = c(6,1,0.2,0))
  plot.new()
  legend("center", legend = colnames(output_SA$consensusTool), pch=15, col = output_SA$col_P3, title="Consensus\n(All Subjects)",cex=0.6,bty="n")


## ---- fig.width=6, fig.height=7, echo=FALSE, results='hide',message=FALSE----
data("output_SA")
  m<- (layout(matrix(c(1,2,3,4,5,6,7,8), nrow=4, byrow = T), heights = c(0.2, 0.2, 0.4, 0.2), widths =  c(0.85,0.15)))
  par(mar = c(0.5,4,2,0))
  par(oma = c(4,0,0,1))
   barplot(output_SA$n_site_all_sub,ylab = "# Sites", las=2,cex.axis = 0.7, cex.names = 1,space = 0, xaxt="n", col="lemonchiffon")
  output_SA$n_site_df$n <- seq(1:dim(output_SA$n_site_df)[1])
  out_n_site <- output_SA$n_site_df[output_SA$n_site_df$outlier==1,]
  n_subj <- dim(output_SA$n_site_df)[1]
  points(x=out_n_site$n-n_subj/100, y=out_n_site$n_site_all_sub+(out_n_site$n_site_all_sub)/10, pch="*", cex=2, col="black", xpd=T)

  plot.new()
  par(mar = c(0.5,4,2,0))
  ##1
 # output_SA$sample_MS <- t(t(output_SA$sample_MS)/colSums(output_SA$sample_MS))
  barplot(as.matrix(output_SA$sample_MS), las = 2, ylab = "% Sites", cex.axis = 0.7, cex.names = 1,space = 0, xaxt="n", col=output_SA$col_P1)
  ind_out <- which(colSums(abs(output_SA$samples_MS_new))>=1)
  if(length(ind_out)>=1){
    for(i_out in 1:length(ind_out)){
      ind_out2 <- which(output_SA$samples_MS_new[,ind_out[i_out]]!=0)
      for(j_out in 1:length(ind_out2)){
        points(x = ind_out[i_out]-dim(output_SA$samples_MS_new)[2]/100, y=1+0.05*j_out, col= output_SA$col_P1[ind_out2[j_out]], pch="*", xpd=T, cex=2)
      }
    }
  }
  par(mar = c(0.5,1,0,0))
  
  plot.new()
  legend("left", legend = rownames(output_SA$sample_MS), pch = 15, col = output_SA$col_P1, title = "", cex = 0.8, bty = "n")
  ##2
  par(mar = c(0.5,4,0,0))
  barplot(t(output_SA$X), las = 2, ylab = "% Sites",cex=1, cex.axis =0.7, cex.names = 1, space = 0, xaxt="n", col=output_SA$col_P2 )
  par(mar = c(0.5,1,0,0))
  plot.new()
  legend("left", legend = colnames(output_SA$X), pch=15, col =  output_SA$col_P2, title = "Consensus\neach subject", cex = 0.9, bty = "n")
  ##3
  par(mar = c(2,4,0,0))
 barplot(output_SA$CS , las = 2, ylab = "CS",space = 0, ylim = c(max(output_SA$CS)+0.2,0), cex.axis = 0.7, col="moccasin")
  points(x=output_SA$out_CS$n-n_subj/100, y=rep(max(output_SA$CS)+0.05,dim(output_SA$out_CS)[1]), pch="*", cex=2, col="black")

## ---- val=T, message=FALSE, warning = FALSE, echo=FALSE------------------
data("output_SA")
df_outlier <- output_SA$df_outlier
df_outlier <- df_outlier[order(rowSums(df_outlier[,2:4]),decreasing = T),]

## ---- eval=TRUE----------------------------------------------------------
head(df_outlier,4)

## ---- fig.width=4, fig.height=4, echo=FALSE, results='hide',message=FALSE----
data("output_SA")
library(RColorBrewer)
plot_matrix_tool <- function(ov_samples_sites){
  par(mar=c(6,6, 1, 1))
  rotate <- function(x) t(apply(x, 2, rev))
  ov_samples_1 <- ov_samples_sites
  ov_samples_2 <- ov_samples_sites


  #plot ratio
  ov_samples_2[lower.tri(ov_samples_2)] <- NA
  diag(ov_samples_2) <- NA
  ov_samples_2_txt <- round( ov_samples_2,2)
  ntool <- dim(ov_samples_2)[1]
  ijpairs <- t(combn(ntool , 2))
  # ov_samples_2 <- log(ov_samples_1+1
  image(rotate(ov_samples_2), col= brewer.pal(n = 6, "Purples"), xaxt="none", yaxt="none")
  grid(ncol(ov_samples_sites), nrow(ov_samples_sites), lty=1, lwd=1)
  axis(1, seq(0, nrow(ov_samples_sites)-1, length.out = nrow(ov_samples_sites))/(ncol(ov_samples_sites)-1), colnames( ov_samples_sites), las=2, cex.axis=0.8)
  axis(2, seq(0, nrow(ov_samples_sites)-1, length.out = nrow(ov_samples_sites))/(ncol(ov_samples_sites)-1), rev(rownames( ov_samples_sites)), las=2, cex.axis=0.8)
  xx <- seq(0, 1, length.out = ncol(ov_samples_sites))
  yy <- seq(0, 1, length.out = nrow(ov_samples_sites))
  ov_samples_2_txt <- rotate(ov_samples_2_txt)
  for(i in 1:nrow(ov_samples_2_txt)){
    for(j in 1:ncol(ov_samples_2_txt)){
      if(!is.na(ov_samples_2_txt[i,j])){
        text((i-1)/(nrow(ov_samples_2_txt)-1), (j-1)/(ncol(ov_samples_2_txt)-1), ov_samples_2_txt[i, j], cex=1)
      }
    }
  }

  #plot co-occurence
  ov_samples_1[upper.tri(ov_samples_1)] <- NA
  ov_samples_1_txt <- round(ov_samples_1,0)
  ov_samples_1 <- log(ov_samples_1+1)
  par(mar=c(5,5, 1, 1))
  image(rotate(ov_samples_1), col=brewer.pal(n = 7, "Blues"), xaxt="none", yaxt="none", add=T)
  grid(ncol(ov_samples_sites), nrow(ov_samples_sites), lty=1, lwd=1)
   ov_samples_1_txt <- rotate(ov_samples_1_txt)
   for(i in 1:nrow(ov_samples_1_txt)){
    for(j in 1:ncol(ov_samples_1_txt)){
      if(!is.na(ov_samples_1_txt[i,j])){
     text((i-1)/(nrow(ov_samples_1_txt)-1), (j-1)/(ncol(ov_samples_1_txt)-1), round(ov_samples_1_txt[i, j],0), cex=1)
      }
    }
  }
}
  plot_matrix_tool(output_SA$ov_tool)

## ---- eval=F, message=FALSE, warning=FALSE-------------------------------
#  sites_ann <- site_annotation(sites, genome = "hg38")

## ---- eval=F, message=FALSE, warning=FALSE, include=F--------------------
#  data(sites_ann)

## ---- eval=T, message=FALSE, warning=FALSE-------------------------------
head(sites_ann)

## ---- eval=TRUE, message=FALSE-------------------------------------------
barplot(table(sites_ann$Location, sites_ann$Tool_ID), col = c(8,1), legend = c("coding", "noncoding"), beside = T)

## ---- eval=F, message=FALSE, warning = FALSE-----------------------------
#  gene_analysis(sites_ann, directory = "/yourpath/output", cores = 2)

## ---- fig.width=4, fig.height=4, echo=FALSE, results='hide',message=FALSE----
data("output_GA")

plot_matrix_subj <- function(ov_sub_cl, ov_cv){
  ov_sub_cl[ov_sub_cl==0]<--1
  rotate <- function(x) t(apply(x, 2, rev))
  ov_samples_sites<-ov_sub_cl
  ov_samples_sites <- log(ov_sub_cl+1)
  ov_samples_sites[is.infinite(ov_samples_sites)] <- -1
  ov_samples_sites[upper.tri(ov_samples_sites)] <- NA
  M2 <- ov_cv
  M2[is.na(M2)] <- -1
  M2[lower.tri(M2)] <- NA

  par(mar = c(5,5,1,1))
  image(rotate(M2), col= c("grey75",brewer.pal(n = 9, "Greens")), breaks=(c(-1,seq(-0.9, max(na.omit(c(M2))), length.out = 10))), xaxt="none", yaxt="none")
  grid(ncol(ov_samples_sites), nrow(ov_samples_sites), lty=1, lwd=0.5)
  axis(1, seq(0, nrow(ov_samples_sites)-1, length.out = nrow(ov_samples_sites))/(ncol(ov_samples_sites)-1), colnames( ov_samples_sites), las=2, cex.axis=0.5)
  axis(2, seq(0, nrow(ov_samples_sites)-1, length.out = nrow(ov_samples_sites))/(ncol(ov_samples_sites)-1), rev(rownames( ov_samples_sites)), las=2, cex.axis=0.5)
  image(rotate(ov_samples_sites), col=c("grey75",rev(heat.colors(9))),breaks=(c(-1,seq(0, max(na.omit(c(ov_samples_sites))), length.out = 10))), xaxt="none", yaxt="none", add=T)
  grid(ncol(ov_samples_sites), nrow(ov_samples_sites), lty=1, lwd=0.5)

  xx <- seq(0, 1, length.out = ncol(ov_samples_sites))
  yy <- seq(0, 1, length.out = nrow(ov_samples_sites))

  ov_sub_bin <- matrix(0,ncol=dim(ov_cv)[1], nrow = dim(ov_cv)[2])
  diag(ov_sub_bin) <- ifelse(diag(ov_cv)>=1,1,0)
  for(i in 1:dim(ov_sub_bin)[1]){
    for(j in 1:dim(ov_sub_bin)[1]){
      if( ov_sub_bin[i,j] == 1){
        text(xx[i], rev(yy)[j], "*", font=2, cex=0.7) #mutated
      }
    }
  }
}



plot_matrix_subj(output_GA$ov_sub_cl, output_GA$ov_sub_cl_CV)


## ---- fig.width=4, fig.height=4, echo=FALSE, results='hide',message=FALSE----
data("output_GA")
 plot(output_GA$freq[,1],  output_GA$sd[,2], xlab="f", ylab="stdev", main="WXS", pch=16, cex=0.6)

## ---- eval=TRUE, message=FALSE-------------------------------------------
library(isma)
ese1 <- ese_allsubj(sites, type = "Site", bin = 30)
ese1tvaf <- ese1$filtering_output$Tumor_Vaf
head(ese1tvaf)
matplot(ese1tvaf[, -1], type = "l", xaxt = "n", col = 1:4, ylab = "#{sites | tumor VAF >= eps}", xlab = "eps", lwd=2, lty=1:4)
axis(1, at = 1:nrow(ese1tvaf), labels = t(round(ese1tvaf$par, 2)), las=2)
legend('topright', inset = .05, legend = colnames(ese1tvaf)[-1], col = 1:4, lty=1:4, lwd=2)

## ---- eval=TRUE, message=FALSE-------------------------------------------
library(isma)
ese2 <- ese_subj_tool(sites, type = "Site")
ese2tvafa0ba <- ese2$filtering_output$Tumor_Vaf$A1NC
head(ese2tvafa0ba)
Tool_ID <- colnames(ese2tvafa0ba[, -1])
matplot(ese2tvafa0ba[,-(1)], type = "l", xaxt = "n",  ylab = "#{sites | tumor VAF >= eps}", xlab = "eps", main = "", lwd=2, col=1:4, lty=1:4)
axis(1, at = 1:nrow(ese2tvafa0ba), labels = t(round(ese2tvafa0ba$par, 2)), las=2)
legend('toprigh', legend = colnames(ese2tvafa0ba)[-1], lty = 1:4, col = 1:4, lwd=2)

## ---- eval=FALSE, cache=FALSE--------------------------------------------
#  sites_TCGA <- integrate_TCGA(sites_ann, genome = "hg38", project = "BRCA", pipeline = "mutect2", gene_info = TRUE, exclude_hypermutated = T)

## ---- val=T, message=FALSE, warning = FALSE, echo=FALSE------------------
data(sites_TCGA)

## ---- eval=TRUE----------------------------------------------------------
colnames(sites_TCGA)

## ---- eval=TRUE----------------------------------------------------------

table(sites_TCGA$Site_TCGA)

## ---- eval=TRUE, message=FALSE, warning=FALSE----------------------------
library(isma)
data(custom_format_example)
print(custom_format_example)

